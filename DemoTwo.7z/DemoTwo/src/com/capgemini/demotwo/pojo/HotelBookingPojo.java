package com.capgemini.demotwo.pojo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class HotelBookingPojo {
	

	@FindBy(how=How.ID, id="txtFirstName")
	private WebElement FirstName;
	
	@FindBy(how=How.ID, id="txtLastName")
	private WebElement LastName;
	
	@FindBy(how=How.ID, id="txtEmail")
	private WebElement Email;
	
	@FindBy(how=How.ID, id="txtPhone")
	private WebElement Phone;
	
	@FindBy(how=How.ID, id="taAddress")
	private WebElement Address;
	
	@FindBy(how=How.NAME, name="city")
	private WebElement City;
	
	@FindBy(how=How.NAME, name="state")
	private WebElement State;
	
	@FindBy(how=How.NAME, name ="persons")
	private WebElement NumOfGuest;
	
	@FindBy(how=How.ID, id="rooms")
	private WebElement NumOfRooms;

	@FindBy(how=How.ID, id ="txtCardholderName")
	private WebElement Name;
	
	@FindBy(how=How.ID, id ="txtDebit")
	private WebElement Number;
	
	@FindBy(how=How.ID, id="txtCvv")
	private WebElement CVV;
	
	@FindBy(how=How.ID, id="txtMonth")
	private WebElement Month;
	
	@FindBy(how=How.ID, id="txtYear")
	private WebElement Year;
	
	@FindBy(how=How.ID, id="btnPayment")
	private WebElement Button;

	public String getFirstName() {
		return FirstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		FirstName.sendKeys(firstName);
	}

	public String getLastName() {
		return LastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		LastName.sendKeys(lastName);
	}

	public String getEmail() {
		return Email.getAttribute("value");
	}

	public void setEmail(String email) {
		Email.sendKeys(email);
	}

	public String getPhone() {
		return Phone.getAttribute("value");
	}

	public void setPhone(String phone) {
		Phone.sendKeys(phone);
	}

	public String getAddress() {
		return Address.getAttribute("value");
	}

	public void setAddress(String address) {
		Address.sendKeys(address);
	}

	public String getCity() {
		return new Select(this.City).getFirstSelectedOption().getText();
	}

	public void setCity(String city) {
		new Select(this.City).selectByVisibleText(city);
	}

	public String getState() {
		return new Select(this.State).getFirstSelectedOption().getText();
	}

	public void setState(String state) {
		new Select(this.State).selectByVisibleText(state);
	}

	public String getNumOfGuest() {
		return new Select(NumOfGuest).getFirstSelectedOption().getText();
	}

	public void setNumOfGuest(String numOfGuest) {
		new Select(this.NumOfGuest).selectByVisibleText(numOfGuest);
	}

	
	public String getName() {
		return Name.getAttribute("value");
	}

	public void setName(String name) {
		Name.sendKeys(name);
	}

	public String getNumber() {
		return Number.getAttribute("value");
	}

	public void setNumber(String number) {
		Number.sendKeys(number);
	}

	public String getCVV() {
		return CVV.getAttribute("value");
	}

	public void setCVV(String cVV) {
		CVV.sendKeys(cVV);
	}

	public String getMonth() {
		return Month.getAttribute("value");
	}

	public void setMonth(String month) {
		Month.sendKeys(month);
	}

	public String getYear() {
		return Year.getAttribute("value");
	}

	public void setYear(String year) {
		Year.sendKeys(year);
	}
	
	public void button() {
		Button.click();
	}
	
}
