package com.capgemini.demotwo.pojo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginPogo extends HotelBookingPojo{

	@FindBy(how=How.NAME, name="userName")
	private WebElement UserName;
	
	@FindBy(how=How.NAME, name="userPwd")
	private WebElement Pwd;
	
	@FindBy(how=How.ID, id="sub")
	private WebElement Sub1;

	public String getUserName() {
		return UserName.getAttribute("value");
	}

	public void setUserName(String userName) {
		UserName.sendKeys(userName);
	}

	public String getPwd() {
		return Pwd.getAttribute("value");
	}

	public void setPwd(String pwd) {
		Pwd.sendKeys(pwd);
	}
	
	public void logins() {
		Sub1.click();
	}
}
