package com.capgemini.demotwo.step;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.demotwo.pojo.HotelBookingPojo;
import com.capgemini.demotwo.pojo.LoginPogo;
import com.capgemini.demotwo.util.HotelBookingUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BookingStepDefination {


	private WebDriver driver;
	private LoginPogo pojo;
	HotelBookingUtil util = new HotelBookingUtil();

	@Before
	public void setUp() throws Exception {
		driver = util.hotelbookingutil("chrome");
		Thread.sleep(3000);
		pojo = new LoginPogo();
		PageFactory.initElements(driver, pojo);
	}

	@After
	public void tearDown() throws Exception {
		driver.close();
	}

	@Test
	public void test() throws Throwable {
		i_have_opened_the_browser();
		username_and_password_are_provided();
		Thread.sleep(3000);
		login_button_must_be_clicked();
		
		//booking_page_is_opened();
		details_are_provided();
		conform_booking_button_is_clicked();
		Thread.sleep(3000);
	}
	
	@Given("^I have opened the browser$")
	public void i_have_opened_the_browser() throws Throwable {
		driver.get("http://localhost:8081/DemoTwo/login.html");
		System.out.println(driver.getTitle());
	//	assertEquals("Hotel Booking", driver.getTitle());
		
		
	}

	@When("^username and password are provided$")
	public void username_and_password_are_provided() throws Throwable {
	pojo.setUserName("capgemini");
		pojo.setPwd("capg1234");
		assertEquals("capgemini", pojo.getUserName());
	}

	@When("^login button must be clicked$")
	public void login_button_must_be_clicked() throws Throwable {
		pojo.logins();
	}

	@When("^booking page is opened$")
	public void booking_page_is_opened() throws Throwable {
		driver.get("D:\\udayabhanu\\DemoTwo\\WebContent\\hotelbooking.html");
	}

	@When("^details are provided$")
	public void details_are_provided() throws Throwable {
		pojo.setFirstName("Udayabhanu");
		pojo.setLastName("Mavuri");
		pojo.setEmail("bhanu@gmail.com");
		pojo.setPhone("9089796696");
		pojo.setAddress("hkgxdsjfcaigcakhvcaifaivsiadgiasdg");
		pojo.setCity("Hyderabad");
		pojo.setState("Telangana");
		pojo.setNumOfGuest("1");
		pojo.setName("bhanu");
		pojo.setNumber("131541fvafv");
		pojo.setCVV("9087");
		pojo.setMonth("October");
		pojo.setYear("2021");
		Thread.sleep(3000);
	}

	@Then("^Conform booking button is clicked$")
	public void conform_booking_button_is_clicked() throws Throwable {
		pojo.button();
		//System.out.println(driver.getWindowHandle());
	}

}
