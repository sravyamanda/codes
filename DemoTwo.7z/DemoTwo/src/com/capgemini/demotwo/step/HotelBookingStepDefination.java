package com.capgemini.demotwo.step;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.demotwo.pojo.HotelBookingPojo;
import com.capgemini.demotwo.util.HotelBookingUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelBookingStepDefination {

	private WebDriver driver;
	private HotelBookingPojo pojo;
	HotelBookingUtil util = new HotelBookingUtil();
	@Before
	public void setUp() throws Exception {
		driver = util.hotelbookingutil("chrome");
		Thread.sleep(3000);
		pojo = new HotelBookingPojo();
		PageFactory.initElements(driver, pojo);
	}

	@After
	public void tearDown() throws Exception {
		driver.close();
	}

	@Test
	public void test() throws Throwable {
		i_have_opened_the_registration_form();
		i_complete_filling_personal_details();
		payment_details();
		i_confirm_booking();
	}

	@Given("^I have opened the registration form$")
	public void i_have_opened_the_registration_form() throws Throwable {
		driver.get("D:\\udayabhanu\\DemoTwo\\WebContent\\hotelbooking.html");
		Thread.sleep(3000);
	}

	@When("^I complete filling personal details$")
	public void i_complete_filling_personal_details() throws Throwable {
		pojo.setFirstName("Udayabhanu");
		pojo.setLastName("Mavuri");
		Thread.sleep(3000);
		pojo.setEmail("bhanu@gmail.com");
		pojo.setPhone("9089796696");
		pojo.setAddress("hkgxdsjfcaigcakhvcaifaivsiadgiasdg");
		Thread.sleep(3000);
		pojo.setCity("Hyderabad");
		pojo.setState("Telangana");
		Thread.sleep(3000);
		pojo.setNumOfGuest("1");
		Thread.sleep(3000);
	}

	@When("^payment details$")
	public void payment_details() throws Throwable {
		pojo.setName("bhanu");
		pojo.setNumber("131541fvafv");
		Thread.sleep(3000);
		pojo.setCVV("9087");
		pojo.setMonth("October");
		Thread.sleep(3000);
		pojo.setYear("2021");
		Thread.sleep(3000);
	}

	@Then("^I confirm booking$")
	public void i_confirm_booking() throws Throwable {
	     pojo.button();
	     Thread.sleep(3000);
	}
}
