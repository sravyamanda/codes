package com.capgemini.demotwo.util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class HotelBookingUtil {

WebDriver driver;
	
	public WebDriver hotelbookingutil(String name){
		if("chrome".equals(name)) {
			System.setProperty("webdriver.chrome.driver","Driver\\chromedriver.exe");
			driver= new ChromeDriver();
			driver.manage().window().maximize();
			return driver;
		}
		else if("firefox".equals(name)) {
			System.setProperty("webdriver.firefox.driver","Driver\\firefox.exe");
			driver= new FirefoxDriver();
			driver.manage().window().maximize();
			return driver;
		}
		else  {
			System.setProperty("webdriver.Internet.driver","Driver\\IE.exe");
			driver= new ChromeDriver();
			driver.manage().window().maximize();
			return driver;
		}
		
	}
	public void close() {
		driver.quit();
	}
}
