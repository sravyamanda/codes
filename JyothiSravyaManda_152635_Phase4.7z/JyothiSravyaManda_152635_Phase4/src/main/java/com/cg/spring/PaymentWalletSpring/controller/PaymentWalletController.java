package com.cg.spring.PaymentWalletSpring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.PaymentWalletSpring.dto.Customer;
import com.cg.spring.PaymentWalletSpring.service.PaymentWalletService;

@RestController
public class PaymentWalletController {

	@Autowired
	PaymentWalletService service;

	@RequestMapping("/customer")
	public List<Customer> Customers() {
		return service.getAllCustomers();
	}

	@RequestMapping("/customer/{mobNo}")
	public double showBalance(@PathVariable String mobNo) {
		return service.showBalance(mobNo);
	}

	@RequestMapping(value = "/customer", method = RequestMethod.POST)
	public void addCustomer(@RequestBody Customer customer) {
		service.createAccount(customer);
	}

	@RequestMapping(value = "/customer/{mobNo}/d/{depositableAmount}", method = RequestMethod.PUT)
	public void depositMoney(@PathVariable String mobNo, @PathVariable Double depositableAmount) {
		service.deposit(mobNo, depositableAmount);
	}

	@RequestMapping(value = "/customer/{mobNo}/w/{withdrawableAmount}", method = RequestMethod.PUT)
	public void withdrawMoney(@PathVariable String mobNo, @PathVariable Double withdrawableAmount) {
			service.withdraw(mobNo, withdrawableAmount);;
		
	}

	@RequestMapping(value = "/customer/{mobNo}/print")
	public String printTransaction(@PathVariable String mobNo) {
		return service.printTransaction(mobNo);

	}

	@RequestMapping(value = "/customer/{SmobNo}/{RecmobNo}/{transferableAmount}", method = RequestMethod.PUT)
	public void fundTransfer(@PathVariable String SmobNo, @PathVariable String RecmobNo,
			@PathVariable double transferableAmount) {
			service.fundTransfer(SmobNo, RecmobNo, transferableAmount);
		
	}

}
