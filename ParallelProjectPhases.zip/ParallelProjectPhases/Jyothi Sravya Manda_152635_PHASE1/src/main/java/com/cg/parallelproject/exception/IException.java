package com.cg.parallelproject.exception;

public interface IException {

	String Message1="Invalid Name";
	String Message2="Invalid MobileNumber";
	String Message3="Amount is not sufficient in your account";
	String Message4="Enter valid mobile number";
	String Message5="Mobile number doesnot exists ";
}
