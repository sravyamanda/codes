package com.capgemini.core.repo;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;
import javax.persistence.EntityManager;

import com.capgemini.core.beans.Customer;
import com.capgemini.core.beans.Transactions;
import com.capgemini.core.beans.Wallet;
import com.capgemini.core.exception.InvalidInputException;
import com.capgemini.core.util.DBUtil;
import com.capgemini.core.util.JPAUtil;

public class WalletRepoImpl implements WalletRepo{
	
	private EntityManager entityManager;
	 public WalletRepoImpl() {
		 super();
		 entityManager = JPAUtil.getEntityManager();
	}
	
	

	@Override
	public boolean save(Customer customer) throws InvalidInputException {
		String mobil=  customer.getMobileNo();
		String name = customer.getName();
		BigDecimal amount = customer.getWallet().getBalance();
		Customer cust = findOne(mobil);
		
		if(cust!=null)
		{
				entityManager.getTransaction().begin();
				entityManager.merge(customer);
				entityManager.getTransaction().commit();
		}else
		{
			entityManager.getTransaction().begin();
			entityManager.persist(customer);
			entityManager.getTransaction().commit();
		}
		return true;


	}

	@Override
	public Customer findOne(String mobileNo) throws InvalidInputException {
		Customer cust = new Customer();
		entityManager.getTransaction().begin();
		cust = entityManager.find(Customer.class, mobileNo);
		if(cust!=null)
		{
				entityManager.getTransaction().commit();
				return cust;
				
		}else {
			entityManager.getTransaction().commit();
			return null;
		}
		
	}

	

	@Override
	public List getTransaction(String mobil) { 
		entityManager.getTransaction().begin();
		Query query = entityManager.createQuery("Select t.statements from Transactions t where t.mobileNo=?",String.class).setParameter(1, mobil);
		List<String> emplist = query.getResultList();
		entityManager.getTransaction().commit();
		return emplist;
	}







	public void saveTransaction(String mobil, String Trans) {
		// TODO Auto-generated method stub
		Transactions tr = new Transactions();
		tr.setMobileNo(mobil);
		tr.setStatements(Trans);
		entityManager.getTransaction().begin();
		entityManager.persist(tr);
		entityManager.getTransaction().commit();
	}

}
