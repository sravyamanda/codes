package com.capgemini.core.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.capgemini.core.beans.Customer;
import com.capgemini.core.beans.Wallet;
import com.capgemini.core.exception.InsufficientBalanceException;
import com.capgemini.core.exception.InvalidInputException;
import com.capgemini.core.repo.WalletRepo;
import com.capgemini.core.repo.WalletRepoImpl;


public class WalletServiceImpl implements WalletService{

	private WalletRepo repo;

	public WalletServiceImpl() {
		repo = new WalletRepoImpl();
	}
	public WalletServiceImpl(Map<String, Customer>data) {
		
	}
	
	public WalletServiceImpl(WalletRepo repo) {
		super();
		this.repo = repo;
	}
	public Customer createAccount(String name, String mobileNo, BigDecimal amount) throws InvalidInputException {
		
			Customer cus = new Customer();
			if(name==null)
				throw new  InvalidInputException("Name cannot be null");
			if(mobileNo==null)
				throw new InvalidInputException("MobileNo cannot be null");
			if(amount==null)
				throw new InvalidInputException("amount cannot be null");
			
			Customer customer=repo.findOne(mobileNo);
			if(isValid(name)  && isValidmobile(mobileNo) && isValidamount(amount)) {
				cus.setName(name);
				cus.setMobileNo(mobileNo);
				cus.setWallet(new Wallet(amount));
				repo.save(cus);
			}else {
				throw new InvalidInputException("Wrong input");
			}
			return cus;		
		}
			
	public Customer showBalance(String mobileNo) throws InvalidInputException {
		if(isValidmobile(mobileNo)) {
		Customer customer=repo.findOne(mobileNo);
		if(customer.getMobileNo()!=null) 
			return customer;
		else 
			throw new InvalidInputException("Invalid mobile number");
		
		}else 
			throw new InvalidInputException("Invalid mobile number");
	}

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) throws InvalidInputException, InsufficientBalanceException {
		if(amount==null)
			throw new InvalidInputException("Please enter some amount");
		if(sourceMobileNo==null)
			throw new InvalidInputException("Please enter source mobilenumber");
		if(targetMobileNo==null)
			throw new InvalidInputException("Please enter destination mobile number");
		
		Customer cust1=repo.findOne(sourceMobileNo);
		Customer cust2=repo.findOne(targetMobileNo);
		if(cust1!=null) {
			if(cust2!=null) {
				BigDecimal bal1=cust1.getWallet().getBalance();
				BigDecimal bal2 =cust2.getWallet().getBalance();
				if(bal1.compareTo(amount)>=0)
				{
					bal1=bal1.subtract(amount);
					cust1.setWallet(new Wallet(bal1));
					repo.save(cust1);
					bal2=bal2.add(amount);
					cust2.setWallet(new Wallet(bal2));
					repo.save(cust2);
					String trans1=new java.util.Date() + " Your account "+sourceMobileNo +" is debited with "+ amount + " towards transfer with "+ targetMobileNo +" balnace is : "+bal1;
					repo.saveTransaction(sourceMobileNo, trans1);
					String trans2= new java.util.Date() + " Your account "+targetMobileNo +" is credited with "+ amount +" towards transfer from "+ sourceMobileNo +" balance is : "+bal2;
					repo.saveTransaction(targetMobileNo, trans2);
				}
				else 
				{
					throw new InsufficientBalanceException("insufficient balance ");
					
				}
				
			}
			else {
				throw new InvalidInputException("Destination mobile number not found");
				
			}
		}else {
			throw new InvalidInputException("source mobile number not found");
		}
		return cust1;
	}

	public Customer depositAmount(String mobileNo, BigDecimal amount) throws InvalidInputException 
	{
		if(amount==null || isValidamount(amount))
			throw new InvalidInputException("Amount cannot be null");
		if(mobileNo==null || isValidmobile(mobileNo))
			throw new InvalidInputException("Source MobileNo cannot be null");
		
		Customer cust=repo.findOne(mobileNo);
		if(cust.getMobileNo()!=null)
		{
				BigDecimal bal = cust.getWallet().getBalance().add(amount);
				cust.setWallet(new Wallet(bal));
				repo.save(cust);
				String trans = new java.util.Date() + " your account "+ mobileNo +" is deposited with "+ amount +" your balance is : "+cust.getWallet().getBalance();
				repo.saveTransaction(mobileNo, trans);
				
		}else
			throw new InvalidInputException("Mobile number not found");
		
		return cust;
	}

	public boolean isValidmobile(String mobileNo) throws InvalidInputException {
		if(mobileNo.matches("[1-9][0-9]{9}")) 
		{
			return true;
		}		
		else 
		    throw new InvalidInputException("Enter correct number");
	}
	public boolean isValid(String name) throws InvalidInputException {
		if(name.matches("[A-Za-z]*")) 
		{
			return true;
		}		
		else 
			throw new InvalidInputException("Enter correct name");
		
	}
	public boolean isValidamount(BigDecimal amount) throws InvalidInputException {
		if(amount.compareTo(new BigDecimal(0))>0) {
		return true;
		} else
			throw new InvalidInputException("Enter sufficient amount");
	}

	public Customer withdrawAmount(String mobileNo, BigDecimal amount) throws InvalidInputException, InsufficientBalanceException 
	{	
		if(amount==null || isValidamount(amount))
			throw new InvalidInputException("mount cannot be null");
		if(mobileNo==null || isValidmobile(mobileNo))
			throw new InvalidInputException("Source mobile no cannot be null");
		Customer cust=repo.findOne(mobileNo);
		if(cust.getMobileNo()==null)
			throw new InvalidInputException("Mobile no not found");
		BigDecimal bal = cust.getWallet().getBalance();
		if(bal.compareTo(amount)>=0)
		{
			bal=bal.subtract(amount);
			cust.setWallet(new Wallet(bal));
			repo.save(cust);
			String trans=new java.util.Date() + " your account "+ mobileNo +" is withdrawed with " + amount +" your balance is: "+cust.getWallet().getBalance();
			repo.saveTransaction(mobileNo, trans);
		}
		else {
			throw new InsufficientBalanceException("Insufficient balance");
			
		}
		return cust;
	
	}

	@Override
	public List getTransaction(String mobil) {
		
		return repo.getTransaction(mobil);
	}
}
