package com.cg.product.ProductCartManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.cg.product.ProductCartManagement")
public class ProductCartManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductCartManagementApplication.class, args);
	}
}
