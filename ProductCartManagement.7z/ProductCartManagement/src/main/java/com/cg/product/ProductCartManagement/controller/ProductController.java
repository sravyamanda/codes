package com.cg.product.ProductCartManagement.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.product.ProductCartManagement.bean.Product;
import com.cg.product.ProductCartManagement.exception.InputInvalidException;
import com.cg.product.ProductCartManagement.service.IProductService;

@RestController
public class ProductController {

	@Autowired
	private IProductService service;
	
	@RequestMapping("/ProductCart")
	public List<Product> getAllProducts(){
		return service.getAllProducts();
	}
	
	@RequestMapping("/ProductCart/{id}")
	public Optional<Product> getProductById(@PathVariable String id) {
		return service.getProductById(id);
	}
	
	@RequestMapping(value = "/ProductCart", method = RequestMethod.POST)
	public void addproduct(@RequestBody Product p) {
		service.addproduct(p);
	}
	
	
	@RequestMapping(value = "/ProductCart/{id}", method = RequestMethod.DELETE)
	public void deleteproduct(@PathVariable String id)  {
		service.deleteproduct(id);
		
	}
	
	@RequestMapping(value = "/ProductCart/{id}", method = RequestMethod.PUT)
	public void updateproduct(@RequestBody Product p,@PathVariable String id) {
		service.updateproduct(p, id);
	}
	
	
	
	
}
