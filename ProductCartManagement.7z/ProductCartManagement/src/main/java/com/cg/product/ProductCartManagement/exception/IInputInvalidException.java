package com.cg.product.ProductCartManagement.exception;

public interface IInputInvalidException {

 String	Message1 ="Enter input properly";
 
}
