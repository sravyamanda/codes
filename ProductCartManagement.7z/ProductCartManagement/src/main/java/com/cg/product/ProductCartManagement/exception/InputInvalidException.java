package com.cg.product.ProductCartManagement.exception;

public class InputInvalidException extends Exception{

	public InputInvalidException() {
		super();
		
}

	public InputInvalidException(String msg) {
		super(msg);
		
}
}
