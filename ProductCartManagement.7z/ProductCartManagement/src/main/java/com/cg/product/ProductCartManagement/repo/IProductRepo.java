package com.cg.product.ProductCartManagement.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.product.ProductCartManagement.bean.Product;

@Repository("IProductRepo")
public interface IProductRepo extends CrudRepository<Product, String>{

}
