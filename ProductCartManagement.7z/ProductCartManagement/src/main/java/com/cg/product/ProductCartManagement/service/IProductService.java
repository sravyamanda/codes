package com.cg.product.ProductCartManagement.service;

import java.util.List;
import java.util.Optional;

import com.cg.product.ProductCartManagement.bean.Product;
import com.cg.product.ProductCartManagement.exception.InputInvalidException;

public interface IProductService {
	
	public void addproduct(Product p);
	public void updateproduct(Product p,String id);
	public void deleteproduct(String id) ;
	public List<Product> getAllProducts();
	public Optional<Product> getProductById(String id);
	
	

}
