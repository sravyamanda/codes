package com.cg.product.ProductCartManagement.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.product.ProductCartManagement.bean.Product;
import com.cg.product.ProductCartManagement.exception.IInputInvalidException;
import com.cg.product.ProductCartManagement.exception.InputInvalidException;
import com.cg.product.ProductCartManagement.repo.IProductRepo;

@Service
public class ProductServiceImpl implements IProductService {

	
	@Autowired
	private IProductRepo repo;
	
	//------------------------    Product Cart Management --------------------------
		/*******************************************************************************************************
		 - Method Name	    :   Add product
		 - Input Parameters	:	beanparameters String
		 - Return Type		:	beanparameters   String
		 - Author			:	M.jyothi sravya
		 - Creation Date	:	08/08/2018
		 ********************************************************************************************************/
	@Override
	public void addproduct(Product p) {
		
		repo.save(p);
	}
	//------------------------    Product Cart Management --------------------------
			/*******************************************************************************************************
			 - Method Name	    :   update product
			 - Input Parameters	:	beanparameters String
			 - Return Type		:	beanparameters   String
			 - Author			:	M.jyothi sravya
			 - Creation Date	:	08/08/2018
			 ********************************************************************************************************/
	@Override
	public void updateproduct(Product p, String id) {
		Product pro=new Product();
		
		pro.setId(id);
		pro.setName(p.getName());
		pro.setModel(p.getModel());
		pro.setPrice(p.getPrice());
		repo.save(pro);
		
		
	}
	//------------------------    Product Cart Management --------------------------
			/*******************************************************************************************************
			 - Method Name	    :   delete product
			 - Input Parameters	:	beanparameters String
			 - Return Type		:	beanparameters   String
			 - Author			:	M.jyothi sravya
			 - Creation Date	:	08/08/2018
			 ********************************************************************************************************/

	@Override
	public void deleteproduct(String id){
		Product pro1=new Product();
		
		repo.deleteById(id);
		
		}
		
	
	//------------------------    Product Cart Management --------------------------
			/*******************************************************************************************************
			 - Method Name	    :  getAllproduct
			 - Input Parameters	:	beanparameters String
			 - Return Type		:	beanparameters   String
			 - Author			:	M.jyothi sravya
			 - Creation Date	:	08/08/2018
			 ********************************************************************************************************/
	@Override
	public List<Product> getAllProducts() {
		List<Product> list = new ArrayList<>();
		repo.findAll().forEach(list::add);
		return list; 
	}
	//------------------------    Product Cart Management --------------------------
			/*******************************************************************************************************
			 - Method Name	    :  getProductById
			 - Input Parameters	:	beanparameters String
			 - Return Type		:	beanparameters   String
			 - Author			:	M.jyothi sravya
			 - Creation Date	:	08/08/2018
			 ********************************************************************************************************/
	@Override
	public Optional<Product> getProductById(String id) {
		
		
		return repo.findById(id);
	
	
	}
	
}
