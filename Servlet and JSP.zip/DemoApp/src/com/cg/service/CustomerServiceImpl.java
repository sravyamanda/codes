package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.CustomerDaoImpl;
import com.cg.dao.ICustomerDao;
import com.cg.dto.Customer;

public class CustomerServiceImpl implements ICustomerService
{
	ICustomerDao custdao=new CustomerDaoImpl();
	
	public boolean addCustomer(Customer cust) 
	{
		//custdao=new CustomerDaoImpl();
		
		return custdao.addCustomer(cust);
		
	}
	public ArrayList<Customer>viewAllCustomer(){
		
	//	custdao=new CustomerDaoImpl();
		
		return custdao.viewAllCustomer();
		
	}
}
