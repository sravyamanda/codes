package com.cg.service;
import java.util.ArrayList;

import com.cg.dto.*;

public interface ICustomerService {

	public abstract boolean addCustomer(Customer cust);
	public abstract  ArrayList<Customer>viewAllCustomer();
}
