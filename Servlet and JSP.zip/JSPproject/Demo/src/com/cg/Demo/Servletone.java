package com.cg.Demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(urlPatterns= {"/Servletone/*","/page1.aspx"})
public class Servletone extends HttpServlet {
	PrintWriter out=null;
	@Override
	public void init() throws ServletException {
		System.out.println("in init");
	}
	@Override
	public void destroy() {
		System.out.println("in destroy");
	}
	@Override
	protected void service(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
		System.out.println("in service");
		doGet(arg0, arg1);
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		out=response.getWriter();
		out.println("<html><head></head><body>");
		out.println("<h1>in do get method</h1>");
		out.println("</body></html>");
		System.out.println("in sysout - in do get");
		
		String serverName=request.getServerName();
		int portNum=request.getServerPort();
		String path=request.getServletPath();
		out.println("server used :"+serverName);
		out.println("port number is:"+portNum);
		out.println("path is:"+path);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
