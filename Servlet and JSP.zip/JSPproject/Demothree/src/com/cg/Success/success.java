package com.cg.Success;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/success.do")
public class success extends HttpServlet {
	PrintWriter out=null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		out=response.getWriter();
		String n= (String) request.getAttribute("name");
		String e = (String) request.getAttribute("emailid");
		String m = (String) request.getAttribute("mob");
		String u = (String) request.getAttribute("username");
		String g = (String) request.getAttribute("gender");
		String ch[] = (String[]) request.getAttribute("course");
		
		out.println("<h1>"+n+"</h1>");
		out.println(e);
		out.println(m);
		out.println(u);
		out.println(g);
		out.println("courses are");
		for (String string : ch) {
			out.println(string+" , ");
		}
		response.getWriter().append("Served at: ").append(request.getContextPath());
				
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
