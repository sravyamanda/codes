package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UserDataController
 */
@WebServlet("/user.do")
public class UserDataController extends HttpServlet {

	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String n= request.getParameter("name").trim();
		String c= request.getParameter("city").trim();
		String m= request.getParameter("mobile").trim();
		long mob=Long.parseLong(m);
		String u= request.getParameter("username").trim();
		String g= request.getParameter("gender").trim();
		String e= request.getParameter("emailid").trim();
		String ch[]= request.getParameterValues("chkcourses");
		
		request.setAttribute("name", n);
		request.setAttribute("city", c);
		request.setAttribute("mob", m);
		request.setAttribute("username", u);
		request.setAttribute("gender", g);
		request.setAttribute("emailid", e);
		request.setAttribute("course", ch);
		RequestDispatcher rd=request.getRequestDispatcher("success.do");
		rd.forward(request, response);
		/*	out=response.getWriter();
		
		String n= request.getParameter("name").trim();
		String c= request.getParameter("city").trim();
		String m= request.getParameter("mobile").trim();
		String u= request.getParameter("username").trim();
		String g= request.getParameter("gender").trim();
		String e= request.getParameter("emailid").trim();
		String ch[]= request.getParameterValues("chkcourses");
			
		
		out.println("<h1> name: "+n+"</h1>");
		out.println("<h1> city: "+c+"</h1>");
		out.println("<h1> mobile: "+m+"</h1>");
		out.println("<h1> username: "+u+"</h1>");
		out.println("<h1> gender: "+g+"</h1>");
		out.println("<h1> emailid: "+e+"</h1>");
		out.println("courses are");
		for (String list : ch) {
			out.println("<h1> courses: "+list+"</h1>");
		}*/
	
		
		
		
		
		
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
