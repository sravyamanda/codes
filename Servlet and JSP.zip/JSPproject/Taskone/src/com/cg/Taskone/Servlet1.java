package com.cg.Taskone;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(urlPatterns= {"/Servlet1","*.do"})

public class Servlet1 extends HttpServlet {
	PrintWriter out=null;
	@Override
	public void init() throws ServletException {
		System.out.println("in init");
	}
	@Override
	public void destroy() {
		System.out.println("in destroy");
	}
	@Override
	protected void service(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
		System.out.println("in service");
		doGet(arg0, arg1);
	}
       
   

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path=request.getServletPath();
		out=response.getWriter();
		
		switch(path) {
		case "/add.do":
			
		add();
		break;
		case "/delete.do":
			
			delete();
			break;
		case "/edit.do":
			
			edit();
			break;
		case "/update.do":
			
			update();
			break;
	}

	}
	


	private void update() {
		out.println("<html><head></head><body>");
		out.println("in update method");
		out.println("</body></html>");
		System.out.println("in update");
	}
	private void edit() {
		out.println("<html><head></head><body>");
		out.println("in edit method");
		out.println("</body></html>");
		System.out.println("in edit");
		
	}
	private void delete() {
		out.println("<html><head></head><body>");
		out.println("in delete method");
		out.println("</body></html>");
		System.out.println("in delete");
	}
	private void add() {
		out.println("<html><head></head><body>");
		out.println("in add method");
		out.println("</body></html>");
		System.out.println("in add");
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
