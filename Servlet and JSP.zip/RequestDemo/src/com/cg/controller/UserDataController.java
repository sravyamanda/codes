package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/user.do")
public class UserDataController extends HttpServlet {

	PrintWriter out=null;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String n=request.getParameter("name").trim();
		String c=request.getParameter("city").trim();
		String m=request.getParameter("mobile").trim();
		long mob=Long.parseLong(m);
		String courseList[]=request.getParameterValues("course");
		
		request.setAttribute("name", n);
		request.setAttribute("cityName", c);
		request.setAttribute("mob", m);
		request.setAttribute("course",courseList);
		RequestDispatcher rd=request.getRequestDispatcher("success.view");// target page url pattern
		rd.forward(request, response);
		
		/*out=response.getWriter();
		  
		String n=request.getParameter("name").trim();
		String c=request.getParameter("city").trim();
		String m=request.getParameter("mobile").trim();
		String courseList[]=request.getParameterValues("course");
		
		out.println("<h1> name : "+n+"</h1>");
		out.println("<h1> city : "+c+"</h1>");
		out.println("<h1> Mobile : "+m+"</h1>");
		out.print("course selected are :");
		for(String l:courseList) {
			out.print(l+" , ");
		}*/
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
