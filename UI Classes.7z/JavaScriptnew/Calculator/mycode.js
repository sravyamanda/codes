function checkMandatory()
{
var fn = document.getElementById("txtFN").value;
var sn = document.getElementById("txtSN").value;
if(fn!="")
{
if(sn!="")
{
return true;
}
else
{
alert('please enter second number');
return false;
}
}
else if(sn!="")
{
if(fn!="")
{
return true;
}
else{
alert('please enter first number');
return false;
}
}
else
alert('Both numbers are mandatory');
return false;
}


function AddNum()
{
var fn = document.getElementById("txtFN").value;
var sn = document.getElementById("txtSN").value;
if (checkMandatory())
{
var result=parseInt(fn)+parseInt(sn);
document.getElementById("txtResult").value=result;
}
}
function SubNum()
{
var fn = document.getElementById("txtFN").value;
var sn = document.getElementById("txtSN").value;
if (checkMandatory())
{
var result=parseInt(fn)-parseInt(sn);
document.getElementById("txtResult").value=result;
}
}
function MulNum()
{
var fn = document.getElementById("txtFN").value;
var sn = document.getElementById("txtSN").value;
if (checkMandatory())
{
var result=parseInt(fn)*parseInt(sn);
document.getElementById("txtResult").value=result;
}
}
function DivNum()
{
var fn = document.getElementById("txtFN").value;
var sn = document.getElementById("txtSN").value;
if (checkMandatory())
{
var result=parseInt(fn)/parseInt(sn);
document.getElementById("txtResult").value=result;
}
}
function PowNum()
{
var fn = document.getElementById("txtFN").value;
var sn = document.getElementById("txtSN").value;
if (checkMandatory())
{
var result=1;
for(var i=0;i<sn;i++)
{
result=result*fn;
}
document.getElementById("txtResult").value=result;
}
}
function ClearValues()
{
document.getElementById("txtFN").value="";
document.getElementById("txtSN").value="";
document.getElementById("txtResult").value="";
}
