package com.cg.DemoIo.ui;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;



public class ReadFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileInputStream  fileInputStream=null;
		StringBuilder stringBuilder=new StringBuilder();
try {
	fileInputStream = new FileInputStream(new File("D://Users//learning//Desktop//file.txt"));
	
	int data;
	while((data=fileInputStream.read()) !=-1) {
	//System.out.println((char)data);
		stringBuilder.append((char)data);
	}
fileInputStream.close();
}catch (FileNotFoundException e) {
System.out.println("Sorry ! File is missing");
	//e.printStackTrace();
} catch (IOException e) {
	System.out.println("Reading Failed");
	//e.printStackTrace();
}
System.out.println(stringBuilder);
FileOutputStream fileOutputStream=null;
try {
	fileOutputStream = new FileOutputStream(new File("D://Users//learning//Desktop//bow.txt"));
	fileOutputStream.write(stringBuilder.toString().getBytes());
	fileOutputStream.close();
} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	
	e.printStackTrace();
} catch (IOException e) {
	// TODO Auto-generated catch block
	//e.printStackTrace();
	System.out.println("Writing failed!!");
}

	}
}
	


