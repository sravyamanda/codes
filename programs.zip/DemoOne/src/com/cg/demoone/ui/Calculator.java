package com.cg.demoone.ui;

public class Calculator {
	public int addNumber(int numone,int numtwo) {
		return numone+numtwo;
	}
	public int subNumber(int numone,int numtwo) {
		return numone-numtwo;
		
	}
	public int mulNumber(int numone,int numtwo) {
		return numone*numtwo;
	}
	public int divNumber(int numone,int numtwo) {
		return numone/numtwo;
	}
}
