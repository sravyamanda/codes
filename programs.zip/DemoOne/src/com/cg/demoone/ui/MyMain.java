package com.cg.demoone.ui;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int numone=Integer.parseInt(args[0]);
int numtwo=Integer.parseInt(args[1]);
Calculator cal=new Calculator();
int addResult=cal.addNumber(numone, numtwo);
int subResult=cal.subNumber(numone, numtwo);
int mulResult=cal.mulNumber(numone, numtwo);
int divResult=cal.divNumber(numone, numtwo);

System.out.println("Addition of 2 Number is "+addResult+"Subtraction is"+subResult);
System.out.println("Multiplication of 2 number is"+mulResult+"Division is"+divResult);
	}

}
