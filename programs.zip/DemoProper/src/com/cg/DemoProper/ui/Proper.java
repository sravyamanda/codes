package com.cg.DemoProper.ui;

import java.io.File;
import java.io.FileReader;
import java.util.Properties;

public class Proper {
public static void main(String[] args) {
	Properties properties = new Properties();
	properties.load(new FileReader(new File()));
	
}
}
