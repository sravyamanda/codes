package com.cg.Demoarraytwo;

public class Mymain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*Employee emp[] = new Employee[3];//0..2
emp[0] = new Employee();
emp[0].setEmpId(1234);
emp[0].setEmpName("abcd");
emp[0].setEmpAge(21);


emp[1] = new Employee();
emp[1].setEmpId(234);
emp[1].setEmpName("bcd");
emp[1].setEmpAge(23);

emp[2] = new Employee();
emp[2].setEmpId(124);
emp[2].setEmpName("acd");
emp[2].setEmpAge(25);

for (Employee emp1 : emp) {
	System.out.println(emp1.getEmpId());
	System.out.println(emp1.getEmpName());
	System.out.println(emp1.getEmpAge());
}*/
		showData(12,23,34,45,56);

		{
			for (int num1 : num) {
				
			}

	private static void showData(int a, int b,) ;
		// TODO Auto-generated method stub
		}
	}

}
