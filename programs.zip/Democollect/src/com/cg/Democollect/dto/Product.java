package com.cg.Democollect.dto;

public class Product {

}
