package com.cg.Democollect.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> myList =new ArrayList();
		
		myList.add("A");
		myList.add("B");
		myList.add("C");
		myList.add("A");
		System.out.println(myList.size());
		System.out.println(myList.get(1));
		myList.remove("B");
		
		System.out.println("---------Enhance for loop---------");
		for(String str:myList) {
			System.out.println(str);
		}
		System.out.println("-----Iterator------");
		Iterator<String> it=myList.iterator();
		while(it.hasNext())
		{
			System.out.println(it.next());
		}
	}

	

}
