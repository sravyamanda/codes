package com.cg.Democompare.ui;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import com.cg.Democompare.dto.Product;

public class Mymainapp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Product proOne=new Product();
proOne.setProdId(1002);
proOne.setProdName("LGT");
proOne.setProdPrice(2541.26);

Product proTwo=new Product();
proTwo.setProdId(1001);
proTwo.setProdName("SamSung");
proTwo.setProdPrice(2647.26);

Product proThree=new Product();
proThree.setProdId(1003);
proThree.setProdName("iphone");
proThree.setProdPrice(3548.24);

List<Product> myList=new LinkedList<>();
myList.add(proOne);
myList.add(proTwo);
myList.add(proThree);
	

Collections.sort(myList);
	for (Product prod : myList) {
		System.out.println("Id is"+prod.getProdId());
		System.out.println("Name is"+prod.getProdName());
		System.out.println("Price is"+prod.getProdPrice());
		
	}
	
	
	}
	

}
