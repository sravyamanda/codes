package com.cg.Demoemp.dao;

import java.util.List;
import java.util.Scanner;

import com.cg.Demoemp.dto.EmployeeDto;
import com.cg.Demoemp.service.IEmployee;
import com.cg.Demoemp.staticdb.Detailsdb;

public class EmployeedaoI implements IEmployee {
	List<EmployeeDto> list = Detailsdb.getDetails();
	@Override
	public List<EmployeeDto> ShowAllDetails() {
		return Detailsdb.getDetails();
	}

	public EmployeeDto searchEmployeeDto(int empId) {
		
		EmployeeDto esearch = null;
		for (EmployeeDto employeeDto : list) {
			if (employeeDto.getEmpId() == empId) {
				esearch = employeeDto;
				break;
			}
		}
		return esearch;
	}

	@Override
	public EmployeeDto editSalary(int eiid1) {
		// TODO Auto-generated method stub
		EmployeeDto sal = null;
		for (EmployeeDto employeeDto : list) {
			if(employeeDto.getEmpId() == eiid1) {
				sal = employeeDto;
				
			}
			
		}
		System.out.println("Enter value to be changed ");
		Scanner scr = new Scanner(System.in);
		double salOne=scr.nextDouble();
		for (EmployeeDto employeeDto : list) {
			if (employeeDto.getEmpId() == sal.getEmpId()) {
				employeeDto.setEmpSalary(salOne);
				sal = employeeDto;
				
			}
			
		}
		return sal;
	}

	@Override
	public void addEmployee(EmployeeDto empOne) {
		// TODO Auto-generated method stub
		list.add(empOne);
	}
}