package com.cg.Demoemp.dao;


	import java.util.List;

	import com.cg.Demoemp.dto.EmployeeDto;

	public interface IEmployee {
	public List<EmployeeDto> ShowAllDetails();
	}


