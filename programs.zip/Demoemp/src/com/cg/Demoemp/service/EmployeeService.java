package com.cg.Demoemp.service;



import java.util.List;

import com.cg.Demoemp.dao.EmployeedaoI;
import com.cg.Demoemp.dto.EmployeeDto;
import com.cg.Demoemp.service.IEmployee;

public class EmployeeService implements IEmployee {
	private IEmployee dao = null;
	public EmployeeService() {
		dao=new EmployeedaoI();
	}

	@Override
	public List<EmployeeDto> ShowAllDetails() {
		// TODO Auto-generated method stub
		return dao.ShowAllDetails();
	}
	@Override
	public EmployeeDto searchEmployeeDto(int eid) {
		// TODO Auto-generated method stub
		return dao.searchEmployeeDto(eid);
	}

	@Override
	public EmployeeDto editSalary(int eiid1) {
		// TODO Auto-generated method stub
		return dao.editSalary(eiid1);
	}

	@Override
	public void addEmployee(EmployeeDto empOne) {
		// TODO Auto-generated method stub
		dao.addEmployee(empOne);
	}

}


