package com.cg.Demoemp.service;

import java.util.List;

import com.cg.Demoemp.dto.EmployeeDto;

public interface IEmployee {
public List<EmployeeDto> ShowAllDetails();

public EmployeeDto searchEmployeeDto(int eid);

public EmployeeDto editSalary(int eiid1);

public void addEmployee(EmployeeDto empOne);
}
