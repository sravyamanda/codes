package com.cg.Demoemp.staticdb;

import java.util.ArrayList;
import java.util.List;

import com.cg.Demoemp.dto.EmployeeDto;

public class Detailsdb {
 private static List<EmployeeDto> Details= null;
static {
	Details=new ArrayList<>();
}
public static List<EmployeeDto> getDetails(){
	EmployeeDto emp=new EmployeeDto();
	EmployeeDto emp1=new EmployeeDto();
	EmployeeDto emp2=new EmployeeDto();
	EmployeeDto emp3=new EmployeeDto();
	
	emp.setEmpId(123);
	emp1.setEmpId(145);
	emp2.setEmpId(134);
	emp3.setEmpId(156);
	
emp.setEmpName("abcd");
emp1.setEmpName("acb");
emp2.setEmpName("xyz");
emp3.setEmpName("ijk");
emp.setEmpSalary(13354);
emp1.setEmpSalary(1546);
emp2.setEmpSalary(567985);
emp3.setEmpSalary(46845);
emp.setEmpDesignation("Analyst");
emp1.setEmpDesignation("Editor");
emp2.setEmpDesignation("dfjhdfg");
emp3.setEmpDesignation("drfhjb");

Details.add(emp);
Details.add(emp1);
Details.add(emp2);
Details.add(emp3);
return Details;

}
}
