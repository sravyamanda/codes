package com.cg.Demoemp.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.Demoemp.dao.EmployeedaoI;
import com.cg.Demoemp.dto.EmployeeDto;

import com.cg.Demoemp.service.IEmployee;

public class EmployeeInfo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int choice = 0;
		IEmployee emps = new EmployeedaoI();
		System.out.println("1. Get all Employee Details");
		System.out.println("2. Get one Employee Details");
		System.out.println("3. Edit Salary");
		do {
			
		
		System.out.println("Enter the choice");
		Scanner scr = new Scanner(System.in);
		choice = scr.nextInt();
		switch (choice) {
		case 1:
			List<EmployeeDto> empservice= emps.ShowAllDetails();
			for (EmployeeDto employeeDto : empservice) {
				System.out.println(employeeDto.getEmpId());
				System.out.println(employeeDto.getEmpName());
				System.out.println(employeeDto.getEmpSalary());
				System.out.println(employeeDto.getEmpDesignation());
			}
			break;

		

		case 2:
			System.out.println("Enter Employee Id");
			int eiid = scr.nextInt();
			EmployeeDto employeeDtoSearch = emps.searchEmployeeDto(eiid);
			if (employeeDtoSearch == null) {
				System.out.println("enter correct id");
			} else {
				System.out.println("Employee Id" + employeeDtoSearch.getEmpId());
				System.out.println("Employee Name" + employeeDtoSearch.getEmpName());
				System.out.println("Employee Salary" + employeeDtoSearch.getEmpSalary());
				System.out.println("Employee Designation" + employeeDtoSearch.getEmpDesignation());
			}
			break;
		case 3:
			System.out.println("Enter Employee id");
			int id = scr.nextInt();
			System.out.println("Enter Employee Name");
			String Name= scr.next();
			System.out.println("Enter Salary ");
			double Salary=scr.nextDouble();
			System.out.println("Enter designation");
			String Designation=scr.next();
			
			EmployeeDto empOne=new EmployeeDto();
			empOne.setEmpId(id);
			empOne.setEmpName(Name);
			empOne.setEmpSalary(Salary);
			empOne.setEmpDesignation(Designation);
			
			emps.addEmployee(empOne);
			break;
		case 4:
			System.out.println("Editing Details");
			System.out.println("Enter Employee Id");
			int eiid1 =scr.nextInt();
			EmployeeDto salChange = emps.editSalary(eiid1);
			if(salChange == null) {
				System.out.println("no data found");
			}else {
				System.out.println(salChange.getEmpId());
				System.out.println(salChange.getEmpName());
				System.out.println(salChange.getEmpSalary());
				System.out.println(salChange.getEmpDesignation());
			}
		}
	}while(choice!=4);
	}

	
}
