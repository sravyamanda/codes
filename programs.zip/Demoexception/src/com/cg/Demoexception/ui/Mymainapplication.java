package com.cg.Demoexception.ui;

public class Mymainapplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
showAllData(10,2);
	}

	private static void showAllData(int one, int two) {
		// TODO Auto-generated method stub
		int a[] = {10,20,30};
		try {
			
		
		int result = one/two;
		System.out.println(a[3]);
		System.out.println(result);
		}
		catch(ArithmeticException ex) {
			System.out.println("Number 2 should not be zero or negative...");
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Index Out of Bound...");
		}
		catch(Exception w) {
			System.out.println("Exception occur...."+w.getMessage());
		}
		
		finally {
			//always execute
			System.out.println("Always Execute...");
		}
		System.out.println("other codes...");
	}

}
