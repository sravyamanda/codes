package com.cg.Demohashmap.ui;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.cg.Demohashmap.dto.Product;

public class Mymainapp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product proOne=new Product();
	 proOne.setProdId(1001);
	 proOne.setProdName("LG");
	 proOne.setProdPrice(45651.14);
	 
	 
	 Product proTwo=new Product();
	 proTwo.setProdId(1003);
	 proTwo.setProdName("IHP");
	 proTwo.setProdPrice(5795.24);
	 
	 Product proThree=new Product();
	 proThree.setProdId(1002);
	 proThree.setProdName("krp");
	 proThree.setProdPrice(26789.214);
	 
		
Map<Integer,Product> myMap=new HashMap<>();
myMap.put(1, proOne);
myMap.put(2, proTwo);
myMap.put(3, proThree);

System.out.println(myMap);
System.out.println(myMap.keySet());//all keys
System.out.println(myMap.get(2));//2 key
	System.out.println(myMap.values());//all values
	
	/*for (Integer keys : myMap.keySet()) {
		System.out.println("keys are"+keys+" value is"+myMap.get(keys));
		
	}
	System.out.println("--iterator--------");
	Set myData=myMap.entrySet();
	Iterator it=myData.iterator();
	
	while(it.hasNext()) {
		System.out.println(it.next());
	}
	}

	private static void setProdId(int i) {
		// TODO Auto-generated method stub
		
	}*/

	
for (Integer keys : myMap.keySet()) {
	System.out.println(myMap.get(keys).getProdId());
	System.out.println(myMap.get(keys).getProdName());
	System.out.println(myMap.get(keys).getProdPrice());
	
}
Collection<Product> myData=myMap.values();
Set<Product> ts = new TreeSet<>(myData);

System.out.println(ts);
for (Product product : ts) {
System.out.println(product.getProdId());
System.out.println(product.getProdName());
System.out.println(product.getProdPrice());
}

	
}
}
