package com.cg.Demologin.dao;

import com.cg.Demologin.dto.UserBean;
import com.cg.Demologin.exception.MyLoginException;

public interface ILogindao {
public String getLoginpassword(UserBean userBean) throws MyLoginException;
}
