package com.cg.Demologin.dao;

import java.util.HashMap;

import com.cg.Demologin.dto.UserBean;
import com.cg.Demologin.exception.IMyLoginExceptionMessages;
import com.cg.Demologin.exception.MyLoginException;
import com.cg.Demologin.staticdb.LoginDB;

public class LogindaoImpl implements ILogindao{

	@Override
	public String getLoginpassword(UserBean userBean) throws MyLoginException {
		String dbPassword="-1";
		try {
		HashMap<String, String>db=LoginDB.getLoginDetails();
		db.get(userBean.getUsername());
		}catch(Exception exception) {
			throw new MyLoginException(IMyLoginExceptionMessages.ERROR1);
		}
		return dbPassword;
	}

}
