package com.cg.Demologin.exception;

public interface IMyLoginExceptionMessages {

	String ERROR1 = "Internal Error.Try Again";

}
