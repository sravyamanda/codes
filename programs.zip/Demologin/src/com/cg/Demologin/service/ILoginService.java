package com.cg.Demologin.service;

import com.cg.Demologin.dto.UserBean;
import com.cg.Demologin.exception.MyLoginException;

public interface ILoginService {

	public boolean validateLogin(UserBean userBean);
	public boolean verifylogin(UserBean userbBean) throws MyLoginException;
}
