package com.cg.Demologin.service;

import com.cg.Demologin.dao.ILogindao;
import com.cg.Demologin.dao.LogindaoImpl;
import com.cg.Demologin.dto.UserBean;
import com.cg.Demologin.exception.MyLoginException;

public class LoginServiceImpl implements ILoginService{
private ILogindao dao;
public LoginServiceImpl() {
	dao=new LogindaoImpl();
	
}
	@Override
	public boolean validateLogin(UserBean userBean) {
		boolean result=false;
		if (userBean.getUsername().trim().length()>4 && userBean.getPassword().trim().length()>4) {
			result=true;
		}
		return result;
	}
	public boolean verifylogin(UserBean userBean) throws MyLoginException {
		boolean output=false;
		String dbPassword=dao.getLoginpassword(userBean);
		if (userBean.getPassword().equals(dbPassword)) {
			output=true;
			
		}
		return output;
	}
	

}
