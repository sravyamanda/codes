package com.cg.Demologin.staticdb;

import java.util.HashMap;

public class LoginDB {

	
		// TODO Auto-generated method stub
		
		private static HashMap<String, String> hashMap= null;
static {
	hashMap=new HashMap<>();
}
public static HashMap<String,String>getLoginDetails(){
	hashMap.put("Sravya","Sravya");
	hashMap.put("Admin","Admin" );
	return hashMap;
}
	

}
