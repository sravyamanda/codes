package com.cg.Demologin.ui;

import java.util.Scanner;

import com.cg.Demologin.dto.UserBean;
import com.cg.Demologin.exception.MyLoginException;
import com.cg.Demologin.service.ILoginService;
import com.cg.Demologin.service.LoginServiceImpl;

public class LoginClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scanner=new Scanner(System.in);
System.out.println("Enter user name");
String username=scanner.next();
System.out.println("Enter password");
String password=scanner.next();
ILoginService service=new LoginServiceImpl();
UserBean userBean=new UserBean();
userBean.setUsername(username);
userBean.setPassword(password);
 boolean result=service.validateLogin(userBean);
if (result) {
	boolean output=false;
	try {
		output = service.verifylogin(userBean);
	} catch (MyLoginException e) {
		System.out.println(e.getMessage());
	}
	if (output){
System.out.println("Welcome"+username);
		
	} else {
System.out.println("Invalid Login.Try again");
	}
} else {
	System.out.println("Invalid Login.Try again");

}
		
	}

}
