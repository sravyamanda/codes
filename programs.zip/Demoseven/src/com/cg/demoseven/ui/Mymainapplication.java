package com.cg.demoseven.ui;

import java.util.Scanner;

import com.cg.demoseven.dto.Employee;

public class Mymainapplication {
	public static void main(String[] args) {
	Employee emp = new Employee();
	System.out.println(emp.hashCode());
	Employee empOne = new Employee();
	System.out.println(empOne.hashCode());

	
	
	emp.setEmpid(1001);
	emp.setEmpName("ABCD");
	emp.setEmpSalary(9988.11);
	System.out.println(emp);
	
	int a=10;
	float b;
	b=a;
	System.out.println(b);
	
	double d=10.45;
	a=(int)d;
	System.out.println(a);
	
	
	/*String str = new String("Hello World");
	Object obj = new Object();
	
	
	str= (String)obj; //down or explicit
	obj = str; //up or implicit*/
	
	Scanner scr = new Scanner(System.in);
	System.out.println("Enter the employee Name");
	String ename=scr.nextLine();
	
	System.out.println("Enter the employee Id");
	int id = scr.nextInt();
	
	
	System.out.println("Enter the Employee Salary");
	double esal=scr.nextDouble();
	
	System.out.println(id+" "+ename+" "+esal);
	
	
	emp.setEmpid(id);
	emp.setEmpName(ename);
	emp.setEmpSalary(esal);
	scr.close();
	System.out.println(emp);
	
	String str = "Capgemini";
	System.out.println(str.length());
	System.out.println(str.substring(3));
	System.out.println(str.concat(" IGate "));
	System.out.println(str.replace("i","p"));
	
	
	String s = str.substring(4,6).concat(" good ");
System.out.println(s);	

String str1 = "Capgemini";
String str2 = "igate";

if(str1.equals(str2)) {
	System.out.println("true");
}
else {
	System.out.println("False");
}
	StringBuffer str3=new StringBuffer("Capgemini");
	str3.append("igate");
	System.out.println(str3);
	
	}
}