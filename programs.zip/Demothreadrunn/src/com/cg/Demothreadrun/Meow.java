package com.cg.Demothreadrun;

public class Meow implements Runnable  {

	public static void main(String[] args) {
		Thread thread = new Thread(new Meow());
		thread.start();
		System.out.println(Thread.currentThread().getName());
		for(int i=0;i<10;i++) {
			System.out.println("jyothi");
		}
	}
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName());
		System.out.println(Thread.currentThread().getId());
		System.out.println(Thread.currentThread().getPriority());
		
		for(int i=0;i<10;i++) {
			try {
				Thread.currentThread().sleep(1000);
				
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("sravya");
		}
		
	}

	
	
}
