package com.cg.elevenone.ui;

public interface ILambda {
	public void power(int number1,int number2);
}
