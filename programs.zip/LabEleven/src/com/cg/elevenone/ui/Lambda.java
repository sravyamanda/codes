package com.cg.elevenone.ui;
import java.util.Scanner;

	
public class Lambda {
	
	
		public Lambda() {
			// TODO Auto-generated constructor stub
			
		}
	public static void main(String[] args) {
		System.out.println("enter a");
		Scanner scanner=new Scanner(System.in);
	     int number1=scanner.nextInt();
	     System.out.println("enter b");
	 	Scanner scanner2=new Scanner(System.in);
	      int number2=scanner2.nextInt();
	ILambda powerr=(a,b)->{
		System.out.println(Math.pow(number1,number2));
	};
	powerr.power(number1,number2);
	}
	}

