package com.cg.LabElevenfive.ui;


	

	import java.util.Scanner;

	public class Factorial {

		public Factorial() {
			// TODO Auto-generated constructor stub
		}
	public static void main(String[] args) {
		System.out.println("enter number ");
		Scanner scanner=new Scanner(System.in);
		int num=scanner.nextInt();

		IFactorial fact=(a)->
		{
			int f=1;
			for(int i=a;i>0;i--)
			f=f*i;	

		System.out.println("factorial is");
		System.out.println(f);
		return f;
		};
	 fact.fact(num);
		}
	}


