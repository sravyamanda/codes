package com.cg.LabElevenfive.ui;

public interface IFactorial {
	 public int fact(int a);
}
