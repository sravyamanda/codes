package com.cg.LabEleventwo;

public interface ISpaceLambda {
	public void space(String str);
}
