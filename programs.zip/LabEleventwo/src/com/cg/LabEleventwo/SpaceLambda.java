package com.cg.LabEleventwo;


	import java.util.Scanner;

	public class SpaceLambda  {

		

		public static void main(String[] args) {
			// TODO Auto-generated method stub
	      //   StringBuilder sb=new StringBuilder();
	        System.out.println("enter string");
	        Scanner scanner=new Scanner(System.in);
	        String str=scanner.nextLine();
	        try {
			ISpaceLambda ispacelambda=(x)->
			{
				
				//sb.append(str);
				for(int i=0;i<str.length();i++)
				{
					if(i==0)
					{
					System.out.print(str.charAt(i));
					System.out.print(" ");
					
					}
					else if(i!=0||i!=str.length()-1)
					{
						
						System.out.print(" ");
						System.out.print(str.charAt(i));
					}
					else if(i==str.length()-1)
					{
						System.out.print(str.charAt(str.length()-1));
					}
				}
			};
				ispacelambda.space(str);	
		
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		}

	}


