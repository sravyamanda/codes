package com.cg.mobile.Test;

import static org.junit.Assert.*;

import org.junit.Test;

public class AccountRechargeTest {

	class Rechargetest {

		@Test
	public void rechargeAccounttestforWrongNumber() {
			assertNotEquals("878545626", "9790756040");
			
		}
		@Test
		public void rechargeAccounttestforcorrectNumber() {
			assertEquals("9533617146", "9533617146");
		}
		
	}
}
