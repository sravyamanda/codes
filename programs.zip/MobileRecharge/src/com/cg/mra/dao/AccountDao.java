package com.cg.mra.dao;

import java.util.HashMap;

import com.cg.mra.beans.Account;

public interface AccountDao {

	Account viewuserdetails(String MobileNo);

	void rechargeamount(String MobileNO1);

}