package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Scanner;

import com.cg.mra.beans.Account;

public class AccountDaoImpl implements AccountDao{
	 private static HashMap<String, Account> details= null;
	 static {
	 	details=new HashMap<>();

	 	Account user=new Account();
	 	user.setMobileNo("9790756040");
	 	user.setAccountBalance(500.00);
	 	user.setCustomerName("sravya");
	 	Account user1=new Account();
	 	user1.setMobileNo("8179299236");
	 	user1.setAccountBalance(400.00);
	 	user1.setCustomerName("honey");
	 	Account user2=new Account();
	 	user2.setMobileNo("9533617146");
	 	user2.setAccountBalance(600.00);
	 	user2.setCustomerName("tiruna");
	 	
	 	
	 	details.put(user.getMobileNo(), user);
	 	details.put(user1.getMobileNo(), user1);
	 	details.put(user2.getMobileNo(), user2);
	 }//------------------------    Recharge Application --------------------------
	/*******************************************************************************************************
	 - Method Name	:	viewuserdetails
	 - Input Parameters	:	MobileNo   String
	 - Return Type		:	MobileNo   String
	 - Author			:	M.jyothi sravya
	 - Creation Date	:	11/07/2018
	 ********************************************************************************************************/
	@Override
	public Account viewuserdetails(String MobileNo) {
		
		return details.get(MobileNo);
	}//------------------------    Recharge Application --------------------------
	/*******************************************************************************************************
	 - Method Name	:	rechargeamount
	 - Input Parameters	:	String MobileNO1
	 - Return Type		:	String MobileNO1
	 - Author			:	M.jyothi sravya
	 - Creation Date	:	11/07/2018
	 ********************************************************************************************************/
	@Override
	public void rechargeamount(String MobileNO1) {
		Scanner scan = new Scanner(System.in);
		Account dto2=new Account();
		for (String MobileNO2 : details.keySet()) {
			if(MobileNO2.equals(MobileNO1)) {
				System.out.println("Enter Recharge Amount");
				double amt=scan.nextDouble();
				dto2=details.get(MobileNO2);
				dto2.setAccountBalance(amt+dto2.getAccountBalance());
			}
			
		}
		;
	}
}
