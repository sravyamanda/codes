package com.cg.mra.exception;

public interface IAccountException {
	String ERROR1="Invalid....Try Again";
}
