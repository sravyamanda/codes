package com.cg.mra.service;

import com.cg.mra.beans.Account;

public interface AccountService {

	Account viewuserdetails(String MobileNo);

	void rechargeamount(String MobileNO1);

	
}
