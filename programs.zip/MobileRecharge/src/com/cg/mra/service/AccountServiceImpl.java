package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService {
AccountDao dao = new AccountDaoImpl();
//------------------------    Recharge Application --------------------------
	/*******************************************************************************************************
	 - Method Name	:	viewuserdetails
	 - Input Parameters	:	MobileNo   String
	 - Return Type		:	MobileNo   String
	 - Author			:	M.jyothi sravya
	 - Creation Date	:	11/07/2018
	 ********************************************************************************************************/
@Override
public Account viewuserdetails(String MobileNo) {

	return dao.viewuserdetails(MobileNo);
}
//------------------------    Recharge Application --------------------------
	/*******************************************************************************************************
	  - Method Name	:	rechargeamount
	 - Input Parameters	:	String MobileNO1
	 - Return Type		:	String MobileNO1
	 - Author			:	M.jyothi sravya
	 - Creation Date	:	11/07/2018
	 ********************************************************************************************************/
@Override
public void rechargeamount(String MobileNO1) {
	dao.rechargeamount(MobileNO1);
	
}
	

}
