package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
AccountService service=new AccountServiceImpl();
int choice=0;
do {
	System.out.println("1.Account Balance Enquiry");
	System.out.println("2.Recharge Account");
	System.out.println("3.Exit");
	Scanner scr = new Scanner(System.in);
	System.out.println("enter the choice:");
	choice = scr.nextInt();
	switch(choice) {
	case 1:
		System.out.println("selected to view user details");

		System.out.println("enter the MobileNo:");
		String MobileNo = scr.next();
		Account dto= service.viewuserdetails(MobileNo);
		if(dto!=null) {
		System.out.println(dto.getAccountBalance());
	}else {
			System.out.println("Given Account Id Does Not Exits");
		
	}
	
	
	break;

	
	case 2 :
   {
	  
	System.out.println("Enter MobileNo");
	Scanner sc =new Scanner(System.in);
	String MobileNO1=sc.next();
	service.rechargeamount(MobileNO1);
	
	
   }
break;
	case 3:
		
}} while (choice<3);
	}
}



