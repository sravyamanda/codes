package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountServiceExceptionImpl;

public interface AccountService {
	public Account getAccountDetails(String mobileNo);
	public double rechargeAccount(String mobileNo, double rechargeAmount);
	public boolean validateMobileNo(String mobileNo) throws AccountServiceExceptionImpl;
	public boolean validateAmount(Double rechargeAmount) throws AccountServiceExceptionImpl;

}
