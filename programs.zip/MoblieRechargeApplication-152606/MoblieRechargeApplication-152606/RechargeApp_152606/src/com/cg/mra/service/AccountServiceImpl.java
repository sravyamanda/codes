package com.cg.mra.service;

import java.util.regex.Pattern;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.AccountServiceException;
import com.cg.mra.exception.AccountServiceExceptionImpl;

public class AccountServiceImpl implements AccountService{
	AccountDao dao = new AccountDaoImpl();
	
	//------------------------    <Recharge> Application --------------------------
	/*******************************************************************************************************
	 - Method Name	:	<getAccountDetails>
	 - Input Parameters	:	<mobileNo> <String>
	 - Return Type		:	<Account> <Account>
	 - Author			:	<Vemsani Priya Chowdary>
	 - Creation Date	:	11/07/2018
	 ********************************************************************************************************/


	@Override
	public Account getAccountDetails(String mobileNo) {
		
		return dao.getAccountDetails(mobileNo);
	}
	//------------------------    <Recharge> Application --------------------------
		/*******************************************************************************************************
		 - Method Name	:	<rechargeAccount>
		 - Input Parameters	:	<mobileNo,rechargeAmount> <String,Double>
		 - Return Type		:	<Double> <Double>
		 - Author			:	<Vemsani Priya Chowdary>
		 - Creation Date	:	11/07/2018
		 ********************************************************************************************************/


	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		return dao.rechargeAccount(mobileNo, rechargeAmount);
	}
	//------------------------    <Recharge> Application --------------------------
			/*******************************************************************************************************
			 - Method Name	:	<validateMobileNo>
			 - Input Parameters	:	<mobileNo> <String>
			 - Return Type		:	<boolean> <boolean>
			 - Author			:	<Vemsani Priya Chowdary>
			 - Creation Date	:	11/07/2018
			 ********************************************************************************************************/


	@Override
	public boolean validateMobileNo(String mobileNo) throws AccountServiceExceptionImpl {
	
		if((mobileNo.length()==10 && Pattern.matches("[0-9]+", mobileNo))) {
			return true;
		}
		else {
			throw new AccountServiceExceptionImpl(AccountServiceException.ERROR1);
		}
		
	}
	//------------------------    <Recharge> Application --------------------------
	/*******************************************************************************************************
	 - Method Name	:	<validateAmount>
	 - Input Parameters	:	<rechargeAmount> <Double>
	 - Return Type		:	<boolean> <boolean>
	 - Author			:	<Vemsani Priya Chowdary>
	 - Creation Date	:	11/07/2018
	 ********************************************************************************************************/


	@Override
	public boolean validateAmount(Double rechargeAmount) throws AccountServiceExceptionImpl {
		String amount = String.valueOf(rechargeAmount);
		if(Pattern.matches("[\\d+.\\d{2}]+", amount) && rechargeAmount>0) {
			return true;
		}
		
		else {
			throw new AccountServiceExceptionImpl(AccountServiceException.ERROR2);
		}
	}

}
