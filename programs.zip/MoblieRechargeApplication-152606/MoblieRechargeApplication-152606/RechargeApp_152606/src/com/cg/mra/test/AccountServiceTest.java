package com.cg.mra.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.AccountServiceExceptionImpl;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class AccountServiceTest {
	
	private static  AccountService service = null;
	
	@BeforeClass
	public static void setUp() {
		service = new AccountServiceImpl();
	}
	@AfterClass
	public static void getUp() {
		System.out.println("testing completed");
	}

	@Test(expected=AccountServiceExceptionImpl.class)
	public void wrongMobileNoTest() throws AccountServiceExceptionImpl {
		
		boolean output = false;
		output = service.validateMobileNo("9848");
		assertFalse(output);
	}
	
	@Test()
	public void correctMobileNoTest() throws AccountServiceExceptionImpl {
	
		boolean output = false;
		output = service.validateMobileNo("9848935458");
		assertTrue(output);
	}
	
	@Test()
	public void correctRechargeAmountTest() throws AccountServiceExceptionImpl{
		
		boolean output = false;
		output = service.validateAmount(100.00);
		assertTrue(output);
	}
	
	@Test()
	public void mobileNoTestWhenInput() {
		Account dto = service.getAccountDetails("9848935458");
		assertNotNull(dto);
	}
	
	@Test()
	public void rechargeAccountTest() {
		double dto = service.rechargeAccount("9848935458", 100.00);
		assertNotNull(dto);
		
	}
	@Test()
	public void rechargeAccountTestOne() {
		AccountDao dao = new AccountDaoImpl();
		double test = dao.rechargeAccount(" ", 10);
		assertNotNull(test);
		
	}
	@Test()
	public void rechargeAccountTestForWrongNumber() {
		assertNotEquals("9848935458","7337421619");
	}
	
	@Test()
	public void rechargeAccountTestForCorrectNumber() {
		assertEquals("9848935458","9848935458");
	}
	

}
