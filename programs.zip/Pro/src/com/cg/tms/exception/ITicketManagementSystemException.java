package com.cg.tms.exception;

public interface ITicketManagementSystemException {

}
