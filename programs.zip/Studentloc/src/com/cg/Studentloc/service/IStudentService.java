package com.cg.Studentloc.service;

public interface IStudentService {

}
