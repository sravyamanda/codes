package com.cg.Studentloc.service;


import java.util.Map;
import java.util.Random;

import com.cg.dao.IStudentDao;
import com.cg.dao.StudentDaoImpl;
import com.cg.dto.StudentDto;

public class StudentServiceImpl implements IStudentService {
	private IStudentDao dao;

	public StudentServiceImpl() {
		dao = new StudentDaoImpl();
	}

	@Override
	public int addStudentDetails(StudentDto student) {
		
		int result = -1;
	
		Map<String, String> collegeDetails = dao.getCollegeDetails();
		if (collegeDetails.containsKey(student.getCity())) {
			int generatedId =(int)( Math.abs( Math.random() * 100000));
			student.setId(generatedId);
			student.setStatus("Approved");
		
			if (dao.addStudentDetails(student)==0) {
				//System.out.println(student.getId());
				result = generatedId;
			}

		}
		return result;
	}

	@Override
	public StudentDto getStatus(int id) {
		return  dao.getStatus(id);
	}

}