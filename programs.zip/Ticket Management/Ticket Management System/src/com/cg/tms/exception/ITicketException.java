package com.cg.tms.exception;

public interface ITicketException {
String ERROR1="Invalid Description";
}
