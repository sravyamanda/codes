package com.cg.tms.service;

import java.util.List;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.TicketException;

public interface TicketService {
	public boolean raiseNewTicket(TicketBean ticketBean);
	public List<TicketCategory>listTicketCategory();
	public boolean validate(String name)throws TicketException;

}
