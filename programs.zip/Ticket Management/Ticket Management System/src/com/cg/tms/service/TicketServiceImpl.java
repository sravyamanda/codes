package com.cg.tms.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.ITicketException;
import com.cg.tms.exception.TicketException;

public class TicketServiceImpl implements TicketService {

	TicketDAO dao = new TicketDAOImpl();
	//------------------------    Ticket Management System --------------------------
	/*******************************************************************************************************
	 - Method Name	    :   Raise new ticket
	 - Input Parameters	:	Dtoparameters String
	 - Return Type		:	Dtoparameters   String
	 - Author			:	M.jyothi sravya
	 - Creation Date	:	21/07/2018
	 ********************************************************************************************************/

	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) {
		ticketBean.setTicketStatus("New");
		int ticketNo = (int) (Math.random() * 100000 + 1);
		ticketBean.setTicketNo(String.valueOf(ticketNo));
		return dao.raiseNewTicket(ticketBean);
	}
	//------------------------    Ticket Management System --------------------------
	/*******************************************************************************************************
	 - Method Name	    :   TicketCategory
	 - Input Parameters	:	Dtoparameters String
	 - Return Type		:	Dtoparameters   String
	 - Author			:	M.jyothi sravya
	 - Creation Date	:	21/07/2018
	 ********************************************************************************************************/
	@Override
	public List<TicketCategory> listTicketCategory() {
		return dao.listTicketCategory();
	}
	
	public boolean validate(String name) throws TicketException {
		// TODO Auto-generated method stub
		boolean result=false;
		if(Pattern.matches("^[a-zA-Z_]+$",name)){
			result=true;
		}else
		{
			throw new TicketException(ITicketException.ERROR1);
		}
		return result;
	}
		
	
		}


