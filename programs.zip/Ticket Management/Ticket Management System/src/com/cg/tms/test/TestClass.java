package com.cg.tms.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.exception.TicketException;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class TestClass {
	
	TicketBean ticketbean=new TicketBean();
	

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Test starts");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Test ends");
	}

	@Test
	public void raiseTicketTest() {
		ticketbean.setTicketDescription("The ticket not available");
		assertEquals("The ticket not available",ticketbean.getTicketDescription());
	}
	@Test(expected=TicketException.class)
	public void testname() throws TicketException{
		TicketService service = new TicketServiceImpl();
		service.validate("123");
	}
	@Test
	public void testnamepositive() throws TicketException{
		TicketService service = new TicketServiceImpl();
		service.validate("mail");
	}
	

}
