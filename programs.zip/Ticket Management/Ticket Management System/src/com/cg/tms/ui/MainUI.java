package com.cg.tms.ui;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;

public class MainUI {
	static TicketService service = new TicketServiceImpl();

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		int choice = 0;
		do {
			System.out.println("1. Raise a Ticket");
			System.out.println("2. Exit from the system");
			System.out.println("Enter your choice");
			choice = scr.nextInt();
			switch (choice) {
			case 1:
				System.out.println("1.software installation");
				System.out.println("2.mailbox creation");
				System.out.println("3.mailbox issues");
				System.out.println("Enter Ticket Category");
				String ticketCategoryId = scr.next();
				List<TicketCategory> categories = service.listTicketCategory();
				TicketBean bean = new TicketBean();
				for (TicketCategory ticketCategory : categories) {
					if (ticketCategory.getTicketCategoryId().equals(ticketCategoryId)) {
						System.out.println("Enter Description related to issue");
						String ticketDescription = scr.next();
						try {
							if(service.validate(ticketDescription)) {
								bean.setTicketDescription(ticketDescription);
							
						
						System.out.println("Enter Priority(1.Low 2.Medium 3.High)");
						String ticketPriority = scr.next();
						
						bean.setTicketCategoryId(ticketCategoryId);
						
						bean.setTicketPriority(ticketPriority);
						boolean output = service.raiseNewTicket(bean);
						
						
						if (output) {
							Date date = new Date();
							SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy hh:mm a");
							String strDate = sdf.format(date);
							System.out.println(
									"Ticket Number: " + bean.getTicketNo() + " logged successfully at " + strDate);
						}
					else {
					System.out.println("Enter Valid Choice");
					}
							}
					}catch (Exception e) {					
						System.out.println(e.getMessage());
					}
				}
				}

				break;
			case 2:
				System.out.println("Thanks for using");
				System.exit(0);
				break;

			default:
				System.out.println("Please Enter Valid Choice");
				break;
			}
		} while (choice <= 2);
	}

}
