package com.cg.tms.dao;

public interface TicketDAO {

}
