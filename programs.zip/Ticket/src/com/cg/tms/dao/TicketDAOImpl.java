package com.cg.tms.dao;

public class TicketDAOImpl {

}
