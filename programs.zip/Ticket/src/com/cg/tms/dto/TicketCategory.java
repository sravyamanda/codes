package com.cg.tms.dto;

public class TicketCategory {
	private String ticketCategoryId;
	private String categoryName;
	
	public TicketCategory() {
		// TODO Auto-generated constructor stub
	}
	public TicketCategory(String ticketCategoryId, String categoryName) {
		super();
		this.ticketCategoryId = ticketCategoryId;
		this.categoryName = categoryName;
	}

	
	public String getTicketcategoryId() {
		return ticketCategoryId;
	}
	public void setTicketcategoryId(String ticketcategoryId) {
		this.ticketCategoryId = ticketcategoryId;
	}
	public String getCategoryname() {
		return categoryName;
	}
	public void setCategoryname(String categoryname) {
		this.categoryName = categoryname;
	}
	
	@Override
	public String toString() {
		return "TicketCategory [ticketCategoryId=" + ticketCategoryId + ", categoryName=" + categoryName + "]";
	}

}
