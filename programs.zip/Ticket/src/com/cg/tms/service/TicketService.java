package com.cg.tms.service;

public interface TicketService {

}
