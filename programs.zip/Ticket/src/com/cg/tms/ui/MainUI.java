package com.cg.tms.ui;

import java.util.Scanner;

public class MainUI {

	public static void main(String[] args) {
		
    Scanner scr=new Scanner(System.in);
 
	}

}
