package com.cg.demo.service;

import java.math.BigDecimal;

import com.cg.demo.beans.Customer;
import com.cg.demo.beans.Wallet;
import com.cg.demo.repo.WalletRepo;
import com.cg.demo.repo.WalletRepoImpl;

public class WalletServiceImpl implements WalletService{
	private WalletRepo repo;

	public WalletServiceImpl() {
		repo = new WalletRepoImpl();
	}

	@Override
	public Customer createAccount(String name, String mobileno, BigDecimal amount) {
		Wallet wallet = new Wallet();
		Customer customer = new Customer();
	
		wallet.setBalance(amount);
		customer.setName(name);
		customer.setMobileNo(mobileno);
		customer.setWallet(wallet);
	
		repo.save(customer);

		return customer;
	}

	@Override
	public Customer showBalance(String mobileno) {
		Customer customer=repo.findOne(mobileno);
		if(customer!=null)
			return customer;
		else
		return null;
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		Customer customer = withdrawAmount(sourceMobileNo, amount);
		depositAmount(targetMobileNo, amount);
		return customer;
	}


	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) {
		Customer customer = repo.findOne(mobileNo);
		Wallet wallet = customer.getWallet();
		wallet.setBalance(wallet.getBalance().add(amount));
	
		if(repo.save(customer)) 
		   return customer;
		return customer;
		
	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		Customer customer = repo.findOne(mobileNo);
		Wallet wallet = customer.getWallet();
		wallet.setBalance(wallet.getBalance().subtract(amount));
	
		if(repo.save(customer)) 
			return customer;
		return customer;
		
	}

}
