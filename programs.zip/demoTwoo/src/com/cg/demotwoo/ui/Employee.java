package com.cg.demotwoo.ui;

public class Employee {
	int empId;
	String empName;
	double empSal;
	boolean s;
	float data;
	public Employee() {
		System.out.println("In constructor....");
	}
public Employee(int empId,String empName,double empSal,boolean s) {
	this.empId=empId;     //this --- Current Object
	this.empName=empName;
	this.empSal=empSal;
	this.s=s;
	
}
public void printAllDetails() {
int temp=10;
System.out.println(temp);

	System.out.println(empId+" "+empName+" "+empSal+" "+s+" "+data);
}
}
