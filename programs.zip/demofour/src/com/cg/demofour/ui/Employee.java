package com.cg.demofour.ui;

public class Employee {
int empId;
static int pf;
}
