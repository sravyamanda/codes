package com.cg.demofour.ui;

public class Mymain {
public static void main(String[] args) {
	Employee.pf=10;
	Employee emp=new Employee();
	emp.empId=1001;
	System.out.println("Employee one"+emp.empId+" "+Employee.pf);
	Employee empone=new Employee();
	empone.empId=44;
	System.out.println("Employee two"+empone.empId+" "+Employee.pf);
	Employee empthree=new Employee();
	System.out.println("Employee three"+empthree.empId+" "+Employee.pf);
	
}

}
