package com.cg.dmeothree.dao;

public class product {

}
