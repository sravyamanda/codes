package com.cg.dmeothree.service;

public class product {

	public int prodId;
}
