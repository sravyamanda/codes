package com.cg.dmeothree.ui;

public class Employee {
	private int empId;
	private String empName;
	private double empSalary;
	
	public int getempId() {
		return empId;
	}
	public  void setempId(int empId) {
		this.empId=empId;
	}
	public String getempName() {
		return empName;
	}
	public void setempName(String empName) {
		this.empName=empName;
	}
	public double getempSalary() {
		return empSalary;
	}
	public void setempSalary(double empSalary) {
		this.empSalary=empSalary;
	}
}
