package com.cg.dmeothree.ui;

import com.cg.dmeothree.dao.product;

public class MyMain {

	public static void main(String[] args) {
		Employee emp=new Employee();
		 com.cg.dmeothree.service.product prod=new com.cg.dmeothree.service.product();
		 com.cg.dmeothree.dao.product prodOne=new product();
		
		prod.prodId=10011;
		emp.setempId(1001);
		emp.setempName("ABCD");
		emp.setempSalary(9849.23);
		System.out.println(emp.getempId()+" "+emp.getempName()+" "+emp.getempSalary());
	}
		// TODO Auto-generated method stub
String ename[]= {"A","B","C","D","E"};
for(int i=0;i<=ename.length-1;i++)
{
	System.out.println(ename[1]);
}
System.out.println("enhance the loop");
for (String str : ename) {
	System.out.println(str);
	// TODO Auto-generated method stub

}
	
}
}
