package com.cg.tentwoone;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

class PersonTest {
Person person = new Person();

   @BeforeClass
   public static void setUp() throws Exception{
	   System.out.println("Testing Starts...");
   }

   @AfterClass
   public static void  setDown() throws Exception{
	   System.out.println("Testing Ends....");
   }

	@Test
	public void testFirstName() {
		person.setFname("Sravya");
	String fname=person.getFname();
	assertEquals("Sravya", fname);
		
	}
	@Test
	public void testLasttName() {
		person.setLname("Manda");
	assertEquals("Manda", person.getLname());
		
	}
	@Test
	public void testGender() {
		person.setGender('F');
		assertEquals('F', person.getGender());
	}

}
