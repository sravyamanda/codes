package com.cg;
@FunctionalInterface
public interface ICalc {
//public int add(int a,int b) ;

	public void add(int a,int b) ;

}
