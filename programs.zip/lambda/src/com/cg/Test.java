package com.cg;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*		ICalc finder = (num1,num2)->num1 + num2;
		int result=finder.add(10,20);
		System.out.println(result);*/
		ICalc calc = (a,b)->{
			System.out.println("meowmeow");
			System.out.println("bowbow");
			System.out.println(a+b);
		};
		calc.add(10, 20);
	}

}
