package com.cg.personclassenum.ui;

public class Mymainenum {
 public static void main(String[] args) {
	 personenum p = new personenum("sravya","Manda",'F',"97907560");
	 
 }
}
