package com.cg.personclassenum.ui;

enum Gender{Male("M"),Female("F");
String gender;
Gender(String g){
	this.gender=g;
}
}


public class personenum {
	private String Firstname;
	private String Lastname;
	private char Gender;
	private String phno;
	Gender gen = null;
public personenum(String Firstname, String Lastname, String phno) {
	this.Firstname = Firstname;
	this.Lastname = Lastname;
	this.phno = phno;
}
	
	


	public String getFirstname() {
		return Firstname;
	}
	public void setFirstname(String Firstname){
		this.Firstname=Firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String Lastname)
	{
		this.Lastname=Lastname;
	}
	public char getGender() {
		return Gender;

	}
	public void setGender(char Gender) {
		this.Gender=Gender;
	}
	public String getphno() {
		return phno;
	}
		public void setphno(String phno)
		{
			this.phno=phno;
		}
	
	public personenum() {
		
	}
	public personenum(String Firstname,String Lastname,char Gender,String phno) {
		System.out.println("person details");
		System.out.println("----------------");
		System.out.println("Firstname"+" "+Firstname);
		System.out.println("Lastname"+" "+Lastname);
		System.out.println("Gender"+" "+Gender);
		System.out.println(("phno"+" "+phno));
	}

	}




