import static org.junit.jupiter.api.Assertions.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

import com.cg.DemoCollege.dao.IStudentDao;
import com.cg.DemoCollege.dao.StudentDaoImpl;
import com.cg.DemoCollege.dto.StudentDetails;
import com.cg.DemoCollege.service.IStudentService;
import com.cg.DemoCollege.service.StudentServiceImpl;

class StudentJunit {

	IStudentDao dao=new StudentDaoImpl();
	IStudentService service= new StudentServiceImpl();
	StudentDetails dto=new StudentDetails();
	@BeforeClass
	public static void setUp() throws Exception{
		System.out.println("Testing Starts");
	}
	@AfterClass
	public static void endUp() throws Exception{
		System.out.println("Testing Ends");
	}
	
	@Test
	public void getCollegeValidTest() {
		
	}
@Test
public void getCollegeNullTest() {
	assertNull(dao.getCityDetails());
}
@Test
public void addStudentTest() {
	dto.setsAge(21);
	dto.setsCity("Chennai");
	dto.setsEmail("jyothi@gmail.com");
	dto.setsGender("F");
	dto.setsName("Sravya");
	dto.setsPhno("9790756040");
	dao.addStudentDao(dto);
	assertEquals("IITChennai", dao.getCityDetails());
	
}
}
