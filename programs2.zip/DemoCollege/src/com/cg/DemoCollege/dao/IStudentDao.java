package com.cg.DemoCollege.dao;

import java.util.Map;

import com.cg.DemoCollege.dto.StudentDetails;


public interface IStudentDao {

	void addStudentDao(StudentDetails details);

	Map<String, String> getCityDetails();



}
