package com.cg.DemoCollege.dao;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import com.cg.DemoCollege.dto.StudentDetails;
import com.cg.DemoCollege.ui.Student;
;

public class StudentDaoImpl implements IStudentDao {
	public static HashMap<String,String> CollegeDetails=null;
	public static HashMap<Integer,StudentDetails> StudentDetails=null;
	static {
		CollegeDetails = new HashMap();
		StudentDetails = new HashMap();
		CollegeDetails.put("Delhi", "IIT-D");
		CollegeDetails.put("Hyd", "IIIT-H");
		CollegeDetails.put("Chennai", "IIT-M");
		CollegeDetails.put("Banglore", "IIS-B");
		CollegeDetails.put("Mumbai", "IIT-B");
	}
	@Override
	public Map<String, String> getCityDetails() {
		// TODO Auto-generated method stub
		return CollegeDetails;
	}
	
	@Override
	public void addStudentDao(StudentDetails details) {
		int generateId = (int) (Math.abs(Math.random()*100000));
		details.setsId(generateId);
		details.setStatus("Approved");
		StudentDetails.put(generateId,details);
		
		String city=details.getsCity()
;
		String collegename=CollegeDetails.get(city);
		details.setCollegeName(collegename);
		StudentDetails.put(generateId, details);
		
	}


	}
	


