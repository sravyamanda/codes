package com.cg.DemoCollege.dto;

import java.time.LocalDate;

public class StudentDetails {
	private String sName;
	private String sPhno;
	private String sEmail;
	private int sAge;
	private String sGender;
	private String sCity;
	private int sId;
	private LocalDate sdoj;
	private String Status="Not Approved";
	private String CollegeName;
	public String getCollegeName() {
		return CollegeName;
	}
	public void setCollegeName(String collegeName) {
		CollegeName = collegeName;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getsPhno() {
		return sPhno;
	}
	public void setsPhno(String sPhno) {
		this.sPhno = sPhno;
	}
	public String getsEmail() {
		return sEmail;
	}
	public void setsEmail(String sEmail) {
		this.sEmail = sEmail;
	}
	public int getsAge() {
		return sAge;
	}
	public void setsAge(int sAge) {
		this.sAge = sAge;
	}
	public String getsGender() {
		return sGender;
	}
	public void setsGender(String sGender) {
		this.sGender = sGender;
	}
	public String getsCity() {
		return sCity;
	}
	public void setsCity(String sCity) {
		this.sCity = sCity;
	}
	public int getsId() {
		return sId;
	}
	public void setsId(int sId) {
		this.sId = sId;
	}
	public LocalDate getDate() {
		return sdoj;
	}
	public void setDate(LocalDate sdoj) {
		this.sdoj = sdoj;
	}

}
