package com.cg.DemoCollege.exception;

public interface IStudentExceptionMessage {

}
