package com.cg.DemoCollege.service;

import com.cg.DemoCollege.dto.StudentDetails;

public interface IStudentService {

	void addStudentDetails(StudentDetails details);

	boolean validateName(StudentDetails details);

	

}
