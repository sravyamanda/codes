package com.cg.DemoCollege.service;


import java.util.Map;

import com.cg.DemoCollege.dao.IStudentDao;


import com.cg.DemoCollege.dao.StudentDaoImpl;
import com.cg.DemoCollege.dto.StudentDetails;

public class StudentServiceImpl implements IStudentService {
	IStudentDao dao=new StudentDaoImpl();
	@Override
	public void addStudentDetails(StudentDetails details) {
		Map<String,String> collegeDetails=dao.getCityDetails();
		dao.addStudentDao(details);
		
	}
	@Override
	public boolean validateName(StudentDetails details) {
		boolean result=false;
		if(details.getsName().matches("[a-zA-Z]+")) {
			if(String.valueOf(details.getsPhno()).trim().length()==10) {
				if(details.getsAge()>0 && details.getsAge()<=99) {
					if(details.getsGender()=="M"||details.getsGender()=="F") {
						result=true;
					}
				}
			}
		}
		return result;
	}
	
}
