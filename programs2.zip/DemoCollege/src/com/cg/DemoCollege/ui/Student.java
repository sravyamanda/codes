package com.cg.DemoCollege.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Random;
import java.util.Scanner;

import com.cg.DemoCollege.dto.StudentDetails;

import com.cg.DemoCollege.service.IStudentService;

import com.cg.DemoCollege.service.StudentServiceImpl;

public class Student {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rand = new Random();
		StudentDetails details = new StudentDetails();
		IStudentService service=new StudentServiceImpl();
System.out.println("1.Add Student Details");
System.out.println("2.view Student Details");
int choice=0;
do {

	System.out.println("Enter the choice");
	Scanner scr = new Scanner(System.in);
	choice = scr.nextInt();
	switch (choice) {
	case 1:
		System.out.println("Enter Student Name");
		String sName=scr.next();
		System.out.println("Enter Student phno");
		String sPhno = scr.next();
		System.out.println("Enter Student email");
		String sEmail=scr.next();
		System.out.println("Enter Age");
		int sAge=scr.nextInt();
		System.out.println("Enter Gender");
		String sGender=scr.next();
		System.out.println("Enter city");
		String sCity=scr.next();
		int sId=rand.nextInt();
		System.out.println("Enter Student doj");
		String sc=scr.next();
		DateTimeFormatter dfm =  DateTimeFormatter.ofPattern("MM-dd-yyyy");
		LocalDate sdoj = LocalDate.parse(sc,dfm);
		details.setsName(sName);
		details.setsPhno(sPhno);
		details.setsEmail(sEmail);
		details.setsAge(sAge);
		details.setsGender(sGender);
		details.setsCity(sCity);
		details.setsId(rand.nextInt());
		
		boolean result=false;
		result=service.validateName(details); 
		
		service.addStudentDetails(details);
		System.out.println(details.getStatus());
		System.out.println(details.getCollegeName());
		
	
	
break;
	case 2:
		System.out.println("view student status");
		if(details.getStatus().equals("Approved")) {
			System.out.println("Student name is:"+details.getsName());
			System.out.println("Student status is:"+details.getStatus());
			System.out.println("college name is:"+details.getCollegeName());
		}
  break;
	case 3:System.exit(0);
	}
	}while(choice<=3);

}
}
