package com.cg.DemoMovie.dao;

public interface IMovieDao {

}
