package com.cg.DemoMovie.dao;

public class MovieDaoImpl {

}
