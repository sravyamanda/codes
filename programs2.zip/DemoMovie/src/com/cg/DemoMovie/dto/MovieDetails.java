package com.cg.DemoMovie.dto;

public class MovieDetails {
private String mName;
private String mHero;
private String mHeroin;
@Override
public String toString() {
	return "MovieDetails [mName=" + mName + ", mHero=" + mHero + ", mHeroin=" + mHeroin + ", mDirector=" + mDirector
			+ ", mProducer=" + mProducer + "]";
}
private String mDirector;
private String mProducer;
public String getmName() {
	return mName;
}
public void setmName(String mName) {
	this.mName = mName;
}
public String getmHero() {
	return mHero;
}
public void setmHero(String mHero) {
	this.mHero = mHero;
}
public String getmHeroin() {
	return mHeroin;
}
public void setmHeroin(String mHeroin) {
	this.mHeroin = mHeroin;
}
public String getmDirector() {
	return mDirector;
}
public void setmDirector(String mDirector) {
	this.mDirector = mDirector;
}
public String getmProducer() {
	return mProducer;
}
public void setmProducer(String mProducer) {
	this.mProducer = mProducer;
}
}
