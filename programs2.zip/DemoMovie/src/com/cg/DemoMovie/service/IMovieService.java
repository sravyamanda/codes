package com.cg.DemoMovie.service;

public interface IMovieService {

}
