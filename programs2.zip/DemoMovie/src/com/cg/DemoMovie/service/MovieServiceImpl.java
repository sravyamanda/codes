package com.cg.DemoMovie.service;

public class MovieServiceImpl {

}
