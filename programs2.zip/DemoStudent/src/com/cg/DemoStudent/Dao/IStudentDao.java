package com.cg.DemoStudent.Dao;

import java.util.HashSet;

import com.cg.DemoStudent.Dto.Student;

public interface IStudentDao {
public void addStudentDao(Student stu);


public HashSet<Student> showalldataDao();


public Student searchStudent(int siid);


public void removeStudent(int rid);

}
