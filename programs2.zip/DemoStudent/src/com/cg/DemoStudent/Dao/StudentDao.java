package com.cg.DemoStudent.Dao;

import java.util.HashSet;

import com.cg.DemoStudent.Dto.Student;

public class StudentDao implements IStudentDao {
public HashSet<Student> myset=new HashSet<>();
	@Override
	public void addStudentDao(Student stu) {
		// TODO Auto-generated method stub
		myset.add(stu);
	}
	
	
	@Override
	public HashSet<Student> showalldataDao() {
		// TODO Auto-generated method stub
		return myset;
	}


	@Override
	public Student searchStudent(int siid) {
		// TODO Auto-generated method stub
		Student ssearch=null;
		for (Student student : myset) {
			if(student.getsId() == siid) {
				ssearch = student;
				break;
			}
			
		}
		return ssearch;
	}


	@Override
	public void removeStudent(int rid) {
		// TODO Auto-generated method stub
		for (Student student : myset) {
			if(student.getsId() == rid) {
				myset.remove(student);
				break;
			}
		}
		
		
	}

}
