package com.cg.DemoStudent.Dto;

import java.time.LocalDate;

public class Student {
private int sId;
private String sName;
private LocalDate dob;
private int sPassingout;
public int getsId() {
	return sId;
}
public void setsId(int sId) {
	this.sId = sId;
}
public String getsName() {
	return sName;
}
public void setsName(String sName) {
	this.sName = sName;
}
public LocalDate getDob() {
	return dob;
}
public void setDob(LocalDate dob) {
	this.dob = dob;
}
public int getsPassingout() {
	return sPassingout;
}
public void setsPassingout(int sPassingout) {
	this.sPassingout = sPassingout;
}

}
