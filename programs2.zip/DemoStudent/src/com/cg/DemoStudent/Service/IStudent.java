package com.cg.DemoStudent.Service;

import java.util.HashSet;

import com.cg.DemoStudent.Dto.Student;

public interface IStudent {

	

	void addStudent(Student stu);

	HashSet<Student> showalldata();

	Student searchStudent(int siid);

	void RemoveStudent(int rid);

}
