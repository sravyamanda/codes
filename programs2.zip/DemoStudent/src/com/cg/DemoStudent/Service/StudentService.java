package com.cg.DemoStudent.Service;

import java.util.HashSet;

import com.cg.DemoStudent.Dao.IStudentDao;
import com.cg.DemoStudent.Dao.StudentDao;
import com.cg.DemoStudent.Dto.Student;

public class StudentService implements IStudent{
IStudentDao dao=new StudentDao();
	@Override
	public void addStudent(Student stu) {
		// TODO Auto-generated method stub
		dao.addStudentDao(stu);
	}
	@Override
	public HashSet<Student> showalldata() {
		// TODO Auto-generated method stub
		return dao.showalldataDao();
	}
	@Override
	public Student searchStudent(int siid) {
		// TODO Auto-generated method stub
		return dao.searchStudent(siid);
	}
	@Override
	public void RemoveStudent(int rid) {
		// TODO Auto-generated method stub
		 dao.removeStudent(rid);
	}

	
}
