package com.cg.DemoStudent.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;

import com.cg.DemoStudent.Dto.Student;
import com.cg.DemoStudent.Service.IStudent;
import com.cg.DemoStudent.Service.StudentService;

public class Mymain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Random rand=new Random();
		IStudent service=new StudentService();
System.out.println("Student Details");
System.out.println("1.Add Student Details");
System.out.println("2.show all student details");
System.out.println("3.Get one student details");
System.out.println("4.delete student");

int choice=0;
do {

	System.out.println("Enter the choice");
	Scanner scr = new Scanner(System.in);
	choice = scr.nextInt();
	switch (choice) {
	
	case 1:
	
	int id=rand.nextInt();
	
	System.out.println("Enter Student Name");
	String sName = scr.next();
	System.out.println("Enter Student dob");
	String sc=scr.next();
	DateTimeFormatter dfm =  DateTimeFormatter.ofPattern("MM-dd-yyyy");
	LocalDate date = LocalDate.parse(sc,dfm);
	
	
	System.out.println("Enter Student passing out");
	int sPassingout=scr.nextInt();
	
	Student stu = new Student();
	stu.setDob(date);
	stu.setsId(rand.nextInt());
	stu.setsName(sName);
	
	stu.setsPassingout(sPassingout);
	
	service.addStudent(stu);
	break;
	
	case 2:
		HashSet<Student> allData = service.showalldata();
		for (Student student : allData) {
			System.out.println(student.getsId());
			System.out.println(student.getsName());
			System.out.println(student.getsPassingout());
			System.out.println(student.getDob());
		
			
		}
		break;
		
	case 3:
		System.out.println("Enter Student Id");
		int siid=scr.nextInt();
		Student studentSearch= service.searchStudent(siid);
		if(studentSearch == null) {
			System.out.println("Enter correct id");
		}else {
			System.out.println(studentSearch.getsId());
			System.out.println(studentSearch.getsName());
			System.out.println(studentSearch.getsPassingout());
			System.out.println(studentSearch.getDob());
		
		}
		break;
		
	case 4:
		System.out.println("Enter product to be remove");
		int rid=scr.nextInt();
		Student Productremove=service.searchStudent(rid);
		if(Productremove !=null) {
			service.RemoveStudent(rid);
		}else {
			System.out.println("Student is not found");
		}
		 
}
	}while(choice!=5);

}

}