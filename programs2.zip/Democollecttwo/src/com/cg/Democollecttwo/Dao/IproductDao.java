package com.cg.Democollecttwo.Dao;

import java.util.List;

import com.cg.Democollecttwo.dto.Product;

public interface IproductDao {

	public void addProductDao(Product pro);
	public List<Product> showAllProductDao();
	public Product searchProduct(int pid);
	public void removeProduct(int prodId);
}
