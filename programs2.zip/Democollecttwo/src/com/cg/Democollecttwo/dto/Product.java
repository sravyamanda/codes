package com.cg.Democollecttwo.dto;

public class Product {
	private int prodId;
	private String ProdName;
	private double ProdPrice;
	public Product() {
		
	}
	@Override
	public String toString() {
		return "Product [prodId=" + prodId + ", ProdName=" + ProdName + ", ProdPrice=" + ProdPrice + "]";
	}
	public Product(int prodId, String prodName, double prodPrice) {
		super();
		this.prodId = prodId;
		ProdName = prodName;
		ProdPrice = prodPrice;
	}
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public String getProdName() {
		return ProdName;
	}
	public void setProdName(String prodName) {
		ProdName = prodName;
	}
	public double getProdPrice() {
		return ProdPrice;
	}
	public void setProdPrice(double prodPrice) {
		ProdPrice = prodPrice;
	}
	public void setProdprice(double pprice) {
		// TODO Auto-generated method stub
		ProdPrice = getProdPrice();
	}
}
