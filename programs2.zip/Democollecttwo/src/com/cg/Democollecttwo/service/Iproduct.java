package com.cg.Democollecttwo.service;

import java.util.List;

import com.cg.Democollecttwo.dto.Product;



public interface Iproduct {
	public void addProductDao(Product prod);
	public List<Product> showAllProductDao();
	public Product searchProduct(int prodid);
	public void removeProduct(int prodId);
}
