package com.cg.Democollecttwo.service;

import java.util.List;

import com.cg.Democollecttwo.Dao.IproductDao;
import com.cg.Democollecttwo.Dao.ProductDaoI;
import com.cg.Democollecttwo.dto.Product;

public class Productservice implements Iproduct {
IproductDao dao = new  ProductDaoI();
	@Override
	public void addProductDao(Product prod) {
		// TODO Auto-generated method stub
		dao.addProductDao(prod);
	}

	@Override
	public List<Product> showAllProductDao() {
		// TODO Auto-generated method stub
		return dao.showAllProductDao();
	}

	@Override
	public Product searchProduct(int prodid) {
		// TODO Auto-generated method stub
		return dao.searchProduct(prodid);
	}

	@Override
	public void removeProduct(int prodId) {
		// TODO Auto-generated method stub
		dao.removeProduct(prodId);
		return;
	}

}
