package com.cg.Democollecttwo.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.Democollecttwo.dto.Product;
import com.cg.Democollecttwo.service.Iproduct;
import com.cg.Democollecttwo.service.Productservice;

public class Mymainapp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int choice=0;
Iproduct ProService= new Productservice();
do {
	printDetails();
	System.out.println("Enter the Choice...");
Scanner scr = new Scanner(System.in);
choice=scr.nextInt();
switch(choice){
	case 1: //Add
		System.out.println("Enter Product ID");
		int pid=scr.nextInt();
		System.out.println("Enter product Name");
		String pname=scr.next();
		System.out.println("Enter product Price");
		double pprice=scr.nextDouble();
		
		Product Prod = new Product();
		Prod.setProdId(pid);
		Prod.setProdName(pname);
		Prod.setProdprice(pprice);
		
		ProService.addProductDao(Prod);
		break;
	case 2:
		List<Product> prolist = ProService.showAllProductDao();
		for (Product proList : prolist) {
			System.out.println("Product Id"+proList.getProdId());
			System.out.println("Product Name"+proList.getProdId());
			System.out.println("Product Price"+proList.getProdId());
		}
		break;
	case 3:
		System.out.println("Enter Product Id..");
		int prodId=scr.nextInt();
		Product productSearch=ProService.searchProduct(prodId);
		if(productSearch.getProdId()==0) {
			System.out.println("Product not Found");
		}else {
			System.out.println("Product Id"+productSearch.getProdId());
			System.out.println("Product Name"+productSearch.getProdId());
			System.out.println("Product Price"+productSearch.getProdId());
		}
		break;
	case 4:
		System.out.println("Enter productid to be remove");
		int rid = scr.nextInt();
		ProService.removeProduct(rid);
		break;
	case 5:
		System.exit(0);
		break;
	
		
		
		
		
}
}while(choice!=5);
}
		
	
	public static void printDetails() {
		System.out.println("1. Add product...");
		System.out.println("2. Show All Product....");
		System.out.println("3. Search Product..");
System.out.println("4. Remove product...");
System.out.println("5. Exit...");
	}
}
