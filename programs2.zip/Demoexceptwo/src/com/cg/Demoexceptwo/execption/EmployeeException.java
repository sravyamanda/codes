package com.cg.Demoexceptwo.execption;

public class EmployeeException extends Exception {

	public EmployeeException() {
		super();
	}
	public EmployeeException(String msg) {
		super(msg);
	}
	
}
