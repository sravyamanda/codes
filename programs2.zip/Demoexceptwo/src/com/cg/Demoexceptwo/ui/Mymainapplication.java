package com.cg.Demoexceptwo.ui;

import java.util.Scanner;

import com.cg.Demoexceptwo.execption.EmployeeException;

public class Mymainapplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*Employee emp = new Employee();
try {
	

emp.getData(10, 0);
}catch(ArithmeticException ex) {
	System.out.println(ex.getMessage());
}*/
		Scanner scr  = new Scanner(System.in);
		System.out.println("Enter the Age");
		int age = scr.nextInt();
		Employee emp = new Employee();
		
		try {
			emp.setEmpAge(age);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println(e.getMessage());
		}

	}

}
