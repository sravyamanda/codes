package com.cg.Demoset.ui;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class Mymain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Set<String> mySet = new HashSet<>();
mySet.add("S");
mySet.add("G");
mySet.add("F");
mySet.add("K");
mySet.add("G");
for(String str : mySet) {
	System.out.println(str);
}
		Set<String> myTreeSet=new TreeSet<>();
		myTreeSet.add("G");
		myTreeSet.add("T");
		myTreeSet.add("R");
		myTreeSet.add("E");
		myTreeSet.add("A");
		for(String str : myTreeSet) {
			System.out.println(str);
			System.out.println("-----iterator----");
			Iterator<String> it=myTreeSet.iterator();
			while(it.hasNext()) {
				System.out.println(it.next());
			}
		}
	} 
}

