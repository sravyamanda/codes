package com.cg.Demothreadthree;

public class Client {
public static void main(String[] args) {
	Display display = new Display();
	MyThread myThread1=new MyThread(display,"Dhoni");
	MyThread myThread2=new MyThread(display,"Kohli");
	myThread1.start();
	try {
		myThread1.wait();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	myThread2.start();
}
}
