import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Proper {
public static void main(String[] args) {
	Properties properties = new Properties();
	try {
		properties.load(new FileReader(new File("D://programs//FIOSerial//Resources//abc.properties")));
		System.out.println();
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
