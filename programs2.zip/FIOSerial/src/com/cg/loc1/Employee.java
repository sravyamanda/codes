package com.cg.loc1;

import java.io.Serializable;

public class Employee implements Serializable {
private Integer  empId;
private String empName;
private Double empSal;
private  transient String empDesig;
public Integer getEmpId() {
	return empId;
}
public void setEmpId(Integer empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public Double getEmpSal() {
	return empSal;
}
public void setEmpSal(Double empSal) {
	this.empSal = empSal;
}
public String getEmpDesig() {
	return empDesig;
}
public void setEmpDesig(String empDesig) {
	this.empDesig = empDesig;
}
}
