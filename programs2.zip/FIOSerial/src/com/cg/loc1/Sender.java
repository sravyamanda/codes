package com.cg.loc1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Sender {

	public static void main(String[] args) throws FileNotFoundException {
 Employee employee = new Employee();
 employee.setEmpId(1002);
 employee.setEmpName("Sravya");
 employee.setEmpDesig("manager");
 employee.setEmpSal(152647.00);

//ObjectOutputStream objectOutputStream=new ObjectOutputStream(new FileOutputStream(new File("D://Users//learning//Desktop//meow.txt")));
 File file = new File("D://Users//learning//Desktop//meow.txt");
 FileOutputStream fos = new FileOutputStream(file);
 ObjectOutputStream oos;
try {
	oos = new ObjectOutputStream(fos);
	 oos.writeObject(employee);
	 System.out.println(oos.hashCode());
	 oos.close();
	 fos.close();
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

 System.out.println("Done..!!");
 
	}

}
