package com.cg.gitexample;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "jyothi sravya" );
    }
}
