package com.cg.LabEleventhree.ui;

public interface IValidation {
	public boolean validate(String username,String password);
}
