package com.cg.LabEleventhree.ui;


	import java.util.Scanner;

	public class Validation {

		public Validation() {
			// TODO Auto-generated constructor stub
		}
	   public static void main(String[] args) {
		System.out.println("enter username");
		Scanner scanner=new Scanner(System.in);
		String user=scanner.nextLine();
		System.out.println("enter password");
		String pswd=scanner.nextLine();
	   String username="admin";
	   String password="admin";
		
		IValidation iv=(a,b)->
		{
			boolean result=false;
			if(user.equals(username)&&pswd.equals(password))
			{
				result=true;
				
				System.out.println("welcome ");
			}
			
			 return result;
		};
			if(iv.validate(user, pswd))
			{
				System.out.println("Continue session");
			}
			else
			{
				System.out.println("try again");
			}
		
	}
	}


