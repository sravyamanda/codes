package com.cg.LabElevenfour;

public class Dao {
	public int getiD() {
		return iD;
	}
	public void setiD(int iD) {
		this.iD = iD;
	}
	public String getNaMe() {
		return naMe;
	}
	public void setNaMe(String naMe) {
		this.naMe = naMe;
	}
	private int iD;
	private String naMe;
	
}
