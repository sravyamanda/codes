package com.cg.LabElevenfour;

public interface IPredicate {
	public void check(Dao dao);
}
