package com.cg.LabElevenfour;


	
	import java.util.ArrayList;
	import java.util.Iterator;
	import java.util.List;
	import java.util.Scanner;

	public class Main {
		// static List<Dao> list=null;
		public Main() {
			// TODO Auto-generated constructor stub
			// list=new ArrayList<>();
		}
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		List<Dao> list=new ArrayList<>();
//		System.out.println("enter skip to not enter id");
//		String skip=scanner.next();
	/*	if(skip.equals("skip"))
		{
			System.out.println("exiting");
			System.exit(0);
		}
		*/
		System.out.println("enter id");
		
		int id=scanner.nextInt();
		//String str=null;
		//String str1=null;
//		System.out.println("enter skip to not enter name");
		//String string2=scanner.next();
		/*if(string2.equals("skip"))
		{
			System.out.println("enter to view");
			System.exit(0);
		}
		*/
		System.out.println("enter name");
		String name=scanner.next();
		
		Dao dao=new Dao();
		dao.setiD(id);
		dao.setNaMe(name);
//		list.add(dao);
		String string1=new String();
		IPredicate predicate=(Str)->
		{
			list.add(dao);
		    if(list.isEmpty())
		    {
		    	System.out.println("enter details to view");
		    }
		    else
		    {
		    	System.out.println("details are");
		    	
				
		    	for(Dao iterator:list)
		    	{
		    		System.out.println("id is"+iterator.getiD());
		    		System.out.println("name is: "+iterator.getNaMe());
		    	}
		    }
		    
		};
		predicate.check(dao);
	}
	}


