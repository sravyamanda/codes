package com.cg.Libraryproject.dao;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class Junittestcases {

	@BeforeClass
	public static void setup() {
		System.out.println("test started");
	}
	@AfterClass
	public static void getup() {
		System.out.println("test completed");
	}
	@Test(expected=)
	public void testId()
	

}
