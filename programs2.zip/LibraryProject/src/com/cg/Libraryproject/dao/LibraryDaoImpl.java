package com.cg.Libraryproject.dao;

import java.util.HashMap;
import java.util.Scanner;

import com.cg.Libraryproject.dto.MemberDto;

public class LibraryDaoImpl implements ILibraryDao {
public static HashMap<String, MemberDto> details=null;

static {
	details=new HashMap<>();

MemberDto mem=new MemberDto();
mem.setmId("123");
mem.setmName("sravya");
mem.setMamount(100.00);

MemberDto mem1=new MemberDto();
mem1.setmId("234");
mem1.setmName("jyothi");
mem1.setMamount(200.00);

MemberDto mem2=new MemberDto();
mem2.setmId("345");
mem2.setmName("bhanu");
mem2.setMamount(300.00);

MemberDto mem3=new MemberDto();
mem3.setmId("456");
mem3.setmName("priya");
mem3.setMamount(400.00);

details.put(mem.getmId(),mem);
details.put(mem1.getmId(),mem1);
details.put(mem2.getmId(),mem2);
details.put(mem3.getmId(), mem3);


}



@Override
public MemberDto viewdetails(String mId) {
	
	return details.get(mId);
}



@Override
public void payAmount(String id) {
	Scanner scan = new Scanner(System.in);
	MemberDto dto2=new MemberDto();
	for (String  id2 : details.keySet()) {
		if(id2.equalsIgnoreCase(id)) {
			System.out.println("Enter Deposit Amount:");
			double amt=scan.nextDouble();
			dto2= details.get(id2);
			dto2.setMamount(amt+dto2.getMamount());
		}
		
	}

	
}
}
