package com.cg.Libraryproject.dto;

public class MemberDto {
String mId;
String mName;
double mamount;
public String getmId() {
	return mId;
}
public void setmId(String mId) {
	this.mId = mId;
}
public String getmName() {
	return mName;
}
public void setmName(String mName) {
	this.mName = mName;
}
public double getMamount() {
	return mamount;
}
public void setMamount(double mamount) {
	this.mamount = mamount;
}
}
