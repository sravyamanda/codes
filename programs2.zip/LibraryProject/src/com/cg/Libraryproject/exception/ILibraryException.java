package com.cg.Libraryproject.exception;

public interface ILibraryException {
String ERROR1="Invalid....Try Again";
}
