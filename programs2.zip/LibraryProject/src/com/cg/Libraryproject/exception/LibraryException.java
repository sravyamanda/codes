package com.cg.Libraryproject.exception;

public class LibraryException extends Exception{
	public LibraryException() {
		// TODO Auto-generated constructor stub
	}
	public LibraryException(String arg)
	{
		super(arg);
	}
}
