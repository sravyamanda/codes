package com.capgemini.core.oop.bean;

public class Customer 
{
	private String name;
	private String mobileNumber;
	private double balance;
	
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Customer(String name, String mobileNumber, double balance) {
		super();
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.balance = balance;
	}


	public Customer(String mobileNumber) {
		super();
		this.mobileNumber = mobileNumber;
	}


	public Customer(String name, double balance) {
		super();
		this.name = name;
		this.balance = balance;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getMobileNumber() {
		return mobileNumber;
	}


	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}


	public double getBalance() {
		return balance;
	}


	public void setBalance(double balance) {
		this.balance = balance;
	}


	@Override
	public String toString() {
		return "Customer [name=" + name + ", mobileNumber=" + mobileNumber + ", balance=" + balance + "]";
	}
	
	
	
	
}
