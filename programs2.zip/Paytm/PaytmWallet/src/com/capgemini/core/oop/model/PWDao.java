package com.capgemini.core.oop.model;

import com.capgemini.core.oop.bean.Customer;

public interface PWDao {

	void addCustomer(Customer customer);

}
