package com.capgemini.core.oop.model;

import java.util.Map;

import com.capgemini.core.oop.bean.Customer;
import com.capgemini.core.oop.util.DBUtil;

public class PWDaoImpl implements PWDao{
	
	DBUtil dbUtil = new DBUtil();
	Map<String, Customer> accounts;
	
	public PWDaoImpl() 
	{
		accounts = dbUtil.getAccounts();
		
	}

	@Override
	public void addCustomer(Customer customer) {
		accounts.put(customer.getMobileNumber(),customer);
		System.out.println(accounts.get(customer.getMobileNumber()));
	}
	
	
	

}
