package com.capgemini.core.oop.service;

import com.capgemini.core.oop.bean.Customer;

public interface PWService {

	void addCustomer(Customer customer);

}
