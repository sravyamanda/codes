package com.capgemini.core.oop.service;

import com.capgemini.core.oop.bean.Customer;
import com.capgemini.core.oop.model.PWDao;
import com.capgemini.core.oop.model.PWDaoImpl;

public class PWServiceImpl implements PWService{
	
	PWDao dao;
	
	public PWServiceImpl() 
	{
		dao = new PWDaoImpl();
	}

	@Override
	public void addCustomer(Customer customer) {
		dao.addCustomer(customer);
		
	}

}
