package com.capgemini.core.oop.util;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.core.oop.bean.Customer;

public class DBUtil 
{
	Map<String, Customer> accounts = new HashMap<>();
	
	{
		
	}

	public Map<String, Customer> getAccounts() {
		return accounts;
	}

	public void setAccounts(Map<String, Customer> accounts) {
		this.accounts = accounts;
	}
	
	

}
