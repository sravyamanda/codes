package com.capgemini.core.oop.view;

import java.util.Scanner;

import com.capgemini.core.oop.bean.Customer;
import com.capgemini.core.oop.service.PWService;
import com.capgemini.core.oop.service.PWServiceImpl;

public class Client 
{
	PWService service;
	Client() {
		service = new PWServiceImpl();
	}
	
	public void menu() {
		
		Customer customer = new Customer();
		System.out.println("Create Account");
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter name");
		String name = sc.next();
		
		System.out.println("Enter mobile Number");
		String phone = sc.next();
		
		System.out.println("Enter amount");
		double balance = sc.nextDouble();
		
		customer.setName(name);
		customer.setMobileNumber(phone);
		customer.setBalance(balance);
		
		service.addCustomer(customer);
		
	}
	
	public static void main(String[] args) 
	{
		Client client = new Client();
		client.menu();
		
	}

}
