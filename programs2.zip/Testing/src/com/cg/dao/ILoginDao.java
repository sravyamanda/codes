package com.cg.dao;

public interface ILoginDao {

	boolean Login(String userName, String password);
	
}

