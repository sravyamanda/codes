package com.cg.service;

public interface ILoginService {

	public boolean login(String userName,String password);
	public String display(String name);
}
