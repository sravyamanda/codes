package com.cg.service;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class LoginServiceImplTest 
{
	private ILoginService service=null;
	@BeforeClass
	public static void beforeClass() {
		System.out.println("before class");
	}
	@AfterClass
	public static void afterClass() {
		System.out.println("after class");
		
	}
	@Before
	public void setp() throws Exception{
		System.out.println("Before");
	}
	@After
	public void tata() throws Exception{
		System.out.println("after");
	}
	@Ignore
	public void test() {
		ILoginService service=new LoginServiceImpl();
		boolean output=service.login("","");
		assertFalse(output);
		
	}

	@Test
	public void testForBlankPassword() {
		ILoginService service=new LoginServiceImpl();
		boolean output=service.login("admin","");
		assertFalse(output);
		
	}

	@Test
	public void testforBlankName() {
		ILoginService service=new LoginServiceImpl();
		boolean output=service.login("","admin");
		assertFalse(output);
		
	}

	@Test
	public void testforWrongInputLength() {
		ILoginService service=new LoginServiceImpl();
		boolean output=service.login("adm","ad");
		assertFalse(output);
		
	}

	@Test
	public void testForWrongInput() {
		ILoginService service=new LoginServiceImpl();
		boolean output=service.login("bowww","meowmeow");
		assertFalse(output);
		
	}

	@Test
	public void testForValidIputs() {
		ILoginService service=new LoginServiceImpl();
		boolean output=service.login("Admin","Admin");
		assertTrue(output);
		
	}
	@Test(expected = NullPointerException.class)
	public void testForNullPointer() {
		ILoginService service=new LoginServiceImpl();
		String out = service.display("bow");
	}
}

