package com.cg.tms.dao;

import java.util.List;
import java.util.Map;

import com.cg.employeedetails.dto.EmployeeDto;
import com.cg.employeedetails.staticdb.EmployeeDatabase;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;

public class TicketDAOImpl implements TicketDao{

	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) {
		// TODO Auto-generated method stub
		TicketBean esearch = null;
		Map<ticketBean,> list = EmployeeDatabase.getdetails();
		for (EmployeeDto employee : list) {
			if(employee.getEmpId()==empid) {
				esearch = employee;
				break;
			}
		}
		return esearch;
		return false;
	}

	@Override
	public List<TicketCategory> listTicketCategory() {
		// TODO Auto-generated method stub
		return null;
	}

}
