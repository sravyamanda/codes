package com.cg.tms.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.service.TicketService;
import com.cg.tms.service.TicketServiceImpl;



public class MainUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner= new Scanner(System.in);
		System.out.println("Welcome to ITIMD Help Desk");
		
		System.out.println("Enter your choice..");
		
		System.out.println("1. Raise a Ticket");
		System.out.println("2. Exit");
		int choice = 0;
		do {
			System.out.println("Enter your choice..");
			choice = scanner.nextInt();
		switch(choice) {	
		case 1 :
			TicketService service =  new TicketServiceImpl();
			TicketBean ticketBean  = new TicketBean();
			TicketCategory ticketCategory = new TicketCategory();
			System.out.println("Select Ticket category from below list");
			System.out.println("1.Software Installation");
			System.out.println("2.Mailbox creation");
			System.out.println("3.Network issues");
			
			System.out.println("enter option");
			
			System.out.println("enter priority(1.low 2.medium 3.high)");
			service.listTicketCategory();
			
			service.raiseNewTicket(ticketBean);
			
			
				
			
			break;
		case 2:
			System.out.println("Thanks for using");
			System.exit(0);
			break;	
		default:
			System.out.println("please enter correct choice");

	}
		
}while(choice<=2);
	}
}
