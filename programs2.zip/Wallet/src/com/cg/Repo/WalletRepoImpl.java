package com.cg.Repo;

import java.util.Map;

import com.cg.bean.Customer;

public class WalletRepoImpl implements WalletRepo{
	private Map<String, Customer> data; 
	

	@Override
	public boolean save(Customer customer) {

		if(data.get(customer.getMobileNo()) == null) {
			data.put(customer.getMobileNo(), customer);
			return true;
		}
		return false;
	}

	@Override
	public Customer findOne(String mobileNo) {
		if(data.get(mobileNo) != null) {
			return data.get(mobileNo);
		}
		return null;
	}

	@Override
	public void remove(String mobileNo) {
		data.remove(mobileNo);
		
	}

}
