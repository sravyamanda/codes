package com.cg.demoeight.ui;

import java.time.Month;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Scanner;

public class MyMainapplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate today = LocalDate.now();
		
		
		System.out.println(today);
		LocalDate myDate=LocalDate.of(2017,Month.APRIL,17);
		System.out.println(myDate.getMonth());
		
		LocalDateTime today1=LocalDateTime.now();
		
System.out.println(today1);
ZonedDateTime zoneIndia=ZonedDateTime.now();
System.out.println(zoneIndia);
ZonedDateTime zoneFrance=ZonedDateTime.now(ZoneId.of("Europe/Paris"));
System.out.println(zoneFrance);

LocalDate joinDate=LocalDate.of(2014, Month.MARCH, 17);
Period diff=joinDate.until(today);

System.out.println("Exp in Number of Years "+diff.getYears());
System.out.println("Exp in Number of Months "+diff.getMonths());
System.out.println("Exp in Number of Days "+diff.getDays());

DateTimeFormatter Formate=DateTimeFormatter.ofPattern("dd/MM/yyyy");
Scanner scr=new Scanner(System.in);
System.out.println("Enter the Date in dd/MM/yyyy");
String date=scr.next();
LocalDate mydate=LocalDate.parse(date,Formate);
System.out.println("Date is"+mydate);
	}

}
