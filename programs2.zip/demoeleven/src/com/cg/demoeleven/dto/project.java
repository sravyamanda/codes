package com.cg.demoeleven.dto;

public class project {

	
	private int projId;
	private String projName;
	public project() {
		
	}
	public project(int projId, String projName) {
		super();
		this.projId = projId;
		this.projName = projName;
	}
	@Override
	public String toString() {
		return "project [projId=" + projId + ", projName=" + projName + "]";
	}
	public int getProjId() {
		return projId;
	}
	public void setProjId(int projId) {
		this.projId = projId;
	}
	public String getProjName() {
		return projName;
	}
	public void setProjName(String projName) {
		this.projName = projName;
	}
}
