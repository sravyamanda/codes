package com.cg.demoeleven.ui;

import java.util.Scanner;

import com.cg.demoeleven.dto.Employee;
import com.cg.demoeleven.dto.project;

public class Mymainapp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner scr=new Scanner(System.in);
		System.out.println("Enter Employee Id");
		int eid=scr.nextInt();
		System.out.println("Enter Employee Name");
		String ename=scr.next();
		System.out.println("Enter Employee Salary");
		double esal=scr.nextDouble();
		System.out.println("Enter project Id");
		int pid=scr.nextInt();
		System.out.println("Enter project Name");
		String pname=scr.next();
		
		project proj=new project();
		proj.setProjId(pid);
		proj.setProjName(pname);
		
		Employee empOne=new Employee();
		empOne.setEmpId(eid);
		empOne.setEmpName(ename);
		empOne.setEmpSalary(esal);
		empOne.setProj(proj);
		
		
		System.out.println("Display All data...");
		System.out.println("Employee Id is"+empOne.getEmpId());
		System.out.println("Employee Name is"+empOne.getEmpName());
		System.out.println("Employee Salary is"+empOne.getEmpSalary());
		System.out.println("Employee Project Id is"+empOne.getProj().getProjId());
		System.out.println("Employee Project Name is"+empOne.getProj().getProjName());
		
		
		
	}

}
