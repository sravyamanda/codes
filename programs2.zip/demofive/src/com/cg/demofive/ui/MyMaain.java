package com.cg.demofive.ui;

public class MyMaain {
	static int data;
	public static void main(String[] args) {
		System.out.println(data);
		new MyMaain();
		getData();
		
	}
	{
		System.out.println("call after static");
	}
	public static void getData() {
		System.out.println("In static block...");
		
	}
	static {// static block
		System.out.println("Execute first...");
	}
public void showData() {
	System.out.println("In non-static..");
	getData();
}
}
