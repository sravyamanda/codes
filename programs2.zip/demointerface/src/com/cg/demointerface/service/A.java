package com.cg.demointerface.service;

public interface A extends IemployeeService {

}
