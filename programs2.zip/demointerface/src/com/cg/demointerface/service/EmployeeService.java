package com.cg.demointerface.service;

public class EmployeeService implements IemployeeService,A {

	@Override
	public void getData() {
		// TODO Auto-generated method stub
		System.out.println("in get Data..");
	}

	@Override
	public double showdata() {
		// TODO Auto-generated method stub
		return 2.0;
	}

}
