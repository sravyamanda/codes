package com.cg.demointerface.service;

public interface IemployeeService {

	public void getData();//public abstract
	public double showdata();//public abstract
	
	
	int a=10; //static final
	
}
