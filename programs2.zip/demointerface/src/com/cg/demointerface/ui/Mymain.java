package com.cg.demointerface.ui;

import com.cg.demointerface.service.EmployeeService;
import com.cg.demointerface.service.IemployeeService;

public class Mymain {
public static void main(String[] args) {
	
	IemployeeService emp = new EmployeeService();
	System.out.println(emp.a);
	emp.getData();
	
	double data = emp.showdata();
	System.out.println(data);
}
}
