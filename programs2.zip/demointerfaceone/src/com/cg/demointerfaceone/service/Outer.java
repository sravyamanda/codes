package com.cg.demointerfaceone.service;

public class Outer {

	public class Inner{
		public void getData() {
			System.out.println(" In Inner class....");
		}
	}
	public void showData() {
		System.out.println(" In Outer class....");
	}
		
	}

