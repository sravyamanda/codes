package com.cg.demointerfaceone.ui;

import com.cg.demointerfaceone.service.Outer;
import com.cg.demointerfaceone.service.Outer.Inner;

public class Mymain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Outer out = new Outer();
		
		out.showData();
//Outer.Inner in = out.new Inner();
Inner in =  out.new Inner();
in.getData();
	}

}
