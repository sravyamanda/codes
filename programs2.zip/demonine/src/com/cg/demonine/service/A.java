package com.cg.demonine.service;

public class A {
	
	/*public A() {
		this(23);
		System.out.println("In constructor A.....");
	}
	public A(int a) {
		System.out.println("In constructor A....."+a);
	}
	public void showData()
	{
		System.out.println("In constructor A");
	}
public 	int eid=10;
	public void getData() {
		System.out.println("In class A");
		
	}*/

}
/*public void getData(int a) {
	System.out.println("In getData"+a);
	
}
public void getData(int a, String str) {
	System.out.println("In getData"+a+str);
}*/

