package com.cg.demonine.service;

public class B extends A {
	/*public B() {
		//super()
		System.out.println("In B constructor.....");
	}
public B(int a) {
	//super()
	this(); //constructor chaining
	System.out.println("In B constructor....."+a);
}*/
	/*public void getData() {
		super.showData();
		System.out.println("In getData");
	}*/
	public void getData() {
		System.out.println("In getData of B");
}
}
