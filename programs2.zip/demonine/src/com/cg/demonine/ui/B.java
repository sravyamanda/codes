package com.cg.demonine.ui;

public class B {

	public void getData() {
		// TODO Auto-generated method stub
		
	}

}
