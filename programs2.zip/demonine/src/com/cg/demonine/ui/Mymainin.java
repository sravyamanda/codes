package com.cg.demonine.ui;
import com.cg.demonine.service.B;
import com.cg.demonine.service.A;
public class Mymainin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*B temp=new B();
		temp.getData();
		System.out.println(temp instanceof A);
		
		temp.getData();
		System.out.println(temp.eid);*/
/*A temp = new A();
temp.getData(235);
temp.getData(11,"Abc");*/

		A temp = new B();
		((B)temp) .getData();
		
	}

}
