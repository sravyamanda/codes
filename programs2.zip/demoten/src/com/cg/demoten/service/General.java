package com.cg.demoten.service;

public class General  extends shift{

	@Override
	public void getLogin() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getLogout() {
		// TODO Auto-generated method stub
		
	}

}
