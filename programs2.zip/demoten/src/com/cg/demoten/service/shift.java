package com.cg.demoten.service;

public abstract class shift {
	//abstract
public abstract void getLogin();
public abstract void getLogout();
//non abstract
public void printAllData() {
	System.out.println("Non-Abstract Method...");
}
}
