package com.cg.demoten.ui;

import com.cg.demoten.service.General;
import com.cg.demoten.service.shift;

public class Mymain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
shift temp=new General();
temp.getLogin();
temp.getLogout();
temp.printAllData();
	}

}
