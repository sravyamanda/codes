package com.cg.eis.exception;

public interface IEmployeeException {
	String ERROR1 = "Internal error.Try Again";
}
