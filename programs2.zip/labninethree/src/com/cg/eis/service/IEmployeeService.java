package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeExceptionImpl;

public interface IEmployeeService {
	public void InsuranceScheme();

	public void InsuranceScheme(int salary, String designation) throws EmployeeExceptionImpl;
	
	public void FileObject(Employee details);

	public void FileObjectDetails(Employee emp);

}
