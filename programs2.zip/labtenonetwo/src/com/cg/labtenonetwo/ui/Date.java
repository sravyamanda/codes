package com.cg.labtenonetwo.ui;

class Date 
     {
	intintDay, intMonth, intYear;
	// Constructor
	Date(int intDay, int intMonth, int intYear)  	{
		this.intDay = intDay;
this.intMonth = intMonth;
this.intYear = intYear;
	}
	// setter and getter methods
	voidsetDay(int intDay)	
	{
		this.intDay = intDay;
	}
		intgetDay( )		
	{
		return  this.intDay;
	}
	
	voidsetMonth(int intMonth)
	{
		this.intMonth = intMonth;
	}

	intgetMonth( )
	{
		return  this.intMonth;
	}

	voidsetYear(int intYear)
	{
		this.intYear=intYear;
	}



	intgetYear( )
	{
		return  this.intYear;
	}
	public String toString() //converts date obj to string.    
	{
		return	�Date is �+intDay+�/�+intMonth+�/�+intYear; 
	}
	
	
	} // Date class

