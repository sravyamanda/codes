package com.cg.eis.bean;

public class EmployeeDetails {
	private int Id ;
	private String Name;
	private int Salary;
	private String Designation ;
	private String InsuScheme;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getSalary() {
		return Salary;
	}
	public void setSalary(int salary) {
		Salary = salary;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		Designation = designation;
	}
	public String getInsuScheme() {
		return InsuScheme;
	}
	public void setInsuScheme(String insuScheme) {
		InsuScheme = insuScheme;
	}
}
