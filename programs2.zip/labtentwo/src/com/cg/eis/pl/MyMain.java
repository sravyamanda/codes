package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.EmployeeDetails;
import com.cg.eis.service.EmployeeServiceImpl;

public class MyMain {
		public static void main(String[] args) {
		Scanner scr=new Scanner(System.in);
	System.out.println("Enter Employee Id");
	int eid=scr.nextInt();
	System.out.println("Enter Employee Name");
	String ename=scr.next();
	System.out.println("Enter Employee Salary");
	int esal=scr.nextInt();
	System.out.println("Enter Employee Designation");
	String edesg=scr.next();

	double n;
	System.out.println("Enter Salary");
	n=scr.nextDouble();

	EmployeeDetails empOne=new EmployeeDetails();
	empOne.setId(eid);
	empOne.setName(ename);
	try {
		empOne.setSalary(esal);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		System.out.println(e.getMessage());
		e.printStackTrace();
	}
	empOne.setDesignation(edesg);




	System.out.println("Display All data...");
	System.out.println("Employee Id is"+empOne.getId());
	System.out.println("Employee Name is"+empOne.getName());
	System.out.println("Employee Salary is"+empOne.getSalary());
	System.out.println("Employee Designation is"+empOne.getDesignation());


	EmployeeServiceImpl emp = new EmployeeServiceImpl();
	
	System.out.println(empOne.getSalary());
	emp.insuranceScheme(esal,edesg);


	}


	}


