package com.cg.eis.service;

import com.cg.eis.exception.EmployeeExceptionImpl;
import com.cg.eis.exception.IEmployeeException;

public class EmployeeServiceImpl implements IEmployeeService {
	





		public void insuranceScheme(double Salary, String designation) {
			// TODO Auto-generated method stub
			  
			if((Salary>5000) && (Salary<20000) && (designation.equals ("System Associate"))) {
				System.out.println("Scheme C");
			}
			else if((Salary>=20000) && (Salary<40000) && (designation.equals ("Programmer"))) {
				System.out.println("Scheme B");
			
			}
			else if ((Salary>=40000) && (designation.equals("Manager"))){
				System.out.println("Scheme A");
			}
			else if 
				((Salary<=5000) && (designation.equals("Clerk")) ) {
				
				
			System.out.println("No Scheme");
			}
			else
				System.out.println("Enter current Salary and designation");
			
		}

		@Override
		public void Salary(int salary) throws EmployeeExceptionImpl {
			// TODO Auto-generated method stub
			if(salary < 3000) {
				throw new EmployeeExceptionImpl(IEmployeeException.ERROR1);
			}
		}

		
		
		}



