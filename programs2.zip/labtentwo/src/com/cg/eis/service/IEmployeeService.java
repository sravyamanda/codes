package com.cg.eis.service;

import com.cg.eis.exception.EmployeeExceptionImpl;

public interface IEmployeeService {
	public  void insuranceScheme(double Salary, String designation);
	//public void  Salary(int salary) throws EmployeeExceptionImpl;
	//public void Salary(double salary) throws EmployeeExceptionImpl;
	
	public void Salary(int salary) throws EmployeeExceptionImpl;
}
