package com.cg.eis.test;

import org.junit.Test;

import org.junit.AfterClass;
import org.junit.BeforeClass;

import com.cg.eis.exception.EmployeeExceptionImpl;
import com.cg.eis.service.EmployeeServiceImpl;
import com.cg.eis.service.IEmployeeService;

public class EmployeeTest {
	@BeforeClass
	public static void setup(){
		System.out.println("test started");
	}

	@AfterClass
	public static void getup(){
		System.out.println("test completed");
	}

	@Test(expected = EmployeeExceptionImpl.class)
	public void testSalary() throws EmployeeExceptionImpl {
		IEmployeeService service = new EmployeeServiceImpl();
		service.Salary(2000);

	}

}
