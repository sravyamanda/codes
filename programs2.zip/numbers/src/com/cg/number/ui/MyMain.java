package com.cg.number.ui;

public class MyMain {
	public static void main(String[] args) {
		checknumber numberone = new checknumber();
		int a;
		a=Integer.parseInt(args[0]);
	numberone.number(a);
				
		
	


personclass per=new personclass();
personclass person=new personclass("Divya","Bharathi",'F');

per.setFirstname("Divya");
per.setLastname("Bharathi");
per.setGender('F');
System.out.println(per.getFirstname()+" "+per.getLastname()+" "+per.getGender());
	}
}
