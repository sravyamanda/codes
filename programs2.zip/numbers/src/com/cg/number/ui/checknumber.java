package com.cg.number.ui;

public class checknumber {
	int n;
	public void number (int n) {
		if(n>0)
			System.out.println("Positive number");
		else
			System.out.println("Negative number");
	}
	

}
