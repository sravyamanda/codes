package com.cg.number.ui;

public class personclass {
private String Firstname;
private String Lastname;
private char Gender;


public String getFirstname() {
	return Firstname;
}
public void setFirstname(String Firstname){
	this.Firstname=Firstname;
}
public String getLastname() {
	return Lastname;
}
public void setLastname(String Lastname)
{
	this.Lastname=Lastname;
}
public char getGender() {
	return Gender;

}
public void setGender(char Gender) {
	this.Gender=Gender;
}
public personclass() {
	
}
public personclass(String Firstname,String Lastname,char Gender) {
	System.out.println(Firstname+" "+Firstname);
	System.out.println(Lastname+" "+Lastname);
	System.out.println(Gender+" "+Gender);
}

}
