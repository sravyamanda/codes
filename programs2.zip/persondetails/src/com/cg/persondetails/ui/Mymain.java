package com.cg.persondetails.ui;

public class Mymain {
public static void main(String[] args) {
	details del = new details("Divya", "Bharathi"," F",20,85.5);
	del.printAllDetails();
}
}
