package com.cg.persondetails.ui;

public class details {
String Firstname;
String Lastname;
String Gender;
int Age;
double Weight;

public details(String Firstname, String Lastname, String Gender, int Age,double weight) {
	this.Firstname = Firstname;
	this.Lastname = Lastname;
	this.Gender = Gender;
	this.Age = Age;
	this.Weight = Weight;
}
public void printAllDetails() {
	System.out.println("person details : ");
	System.out.println("----------------");
	System.out.println(" Divya");
	System.out.println(" Bharathi");
	System.out.println("F");
	System.out.println( 20);
	System.out.println(85.55);
	
}

}
