package com.cg.personclassph.ui;
	



public class Mymainph {
	
	public static void main(String[] args) {
		
	personclassph per=new personclassph();
	personclassph person=new personclassph("Divya","Bharathi",'F',"9790756040");

	per.setFirstname("Divya");
	per.setLastname("Bharathi");
	per.setGender('F');
	per.setphno("9790756040");
	System.out.println(per.getFirstname()+" "+per.getLastname()+" "+per.getGender()+" "+per.getphno());
}
}