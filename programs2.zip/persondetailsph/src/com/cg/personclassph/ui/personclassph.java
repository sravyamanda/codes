package com.cg.personclassph.ui;

public class personclassph {
	private String Firstname;
	private String Lastname;
	private char Gender;
	private String phno;


	public String getFirstname() {
		return Firstname;
	}
	public void setFirstname(String Firstname){
		this.Firstname=Firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String Lastname)
	{
		this.Lastname=Lastname;
	}
	public char getGender() {
		return Gender;

	}
	public void setGender(char Gender) {
		this.Gender=Gender;
	}
	public String getphno() {
		return phno;
	}
		public void setphno(String phno)
		{
			this.phno=phno;
		}
	
	public personclassph() {
		
	}
	public personclassph(String Firstname,String Lastname,char Gender,String phno) {
		System.out.println("person details");
		System.out.println("----------------");
		System.out.println("Firstname"+" "+Firstname);
		System.out.println("Lastname"+" "+Lastname);
		System.out.println("Gender"+" "+Gender);
		System.out.println(("phno"+" "+phno));
	}

	}

