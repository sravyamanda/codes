package com.cg.basic;

public class DrawingApp  {

	public static void main(String[] args) {
	
		Triangle tri= new Triangle();
		
		tri.draw();
	}

	
		
		
	

}
