package com.cg.basic;

public class Triangle {

	private Point point;
	public void draw() {
		System.out.println("drawing a triangle");
	}

	
}
