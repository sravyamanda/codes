package com.cg.spring.core;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.spring.core.beans.Address;
import com.cg.spring.core.beans.Customer;

public class Main {

	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		context.registerShutdownHook();
		Customer c = (Customer) context.getBean("customer");
		c.showProducts();
		Address a=	(Address) context.getBean("addr");
		a.print();

	}

}
