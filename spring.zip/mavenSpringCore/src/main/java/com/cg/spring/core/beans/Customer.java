package com.cg.spring.core.beans;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Customer{
	
	private int id;
	private String name;
	private List<Product> list;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Product> getList() {
		return list;
	}
	public void setList(List<Product> list) {
		this.list = list;
	}
	
	public void showProducts() {
		//System.out.println("Product name: "+ getProduct().getProduct_name());
		//System.out.println("Product price: "+ getProduct().getProduct_price());
		for (Product p : list) {
			System.out.println("name: "+p.getProduct_name());
			System.out.println("price: "+p.getProduct_price());
			System.out.println("------------------------------");
			
		}
		

	}
	/*public void afterPropertiesSet() throws Exception {
		System.out.println("Init method for customer");
		
	}*/
	@PreDestroy
	public void destroy() {
		System.out.println("Destroy method for customer");
		
	}
	
	@PostConstruct
public void init() {
	System.out.println("Init for customers");
}
	
}
